$(function() {
    $('#side-menu').metisMenu();
});

//Loads the correct sidebar on window load,
//collapses the sidebar on window resize.
// Sets the min-height of #page-wrapper to window size
$(function() {
//    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) { }
    $(window).bind("load resize", function() {
        topOffset = 50;
        width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
        if (width < 768) {
            $('div.navbar-collapse').addClass('collapse');
            topOffset = 100; // 2-row-menu
        } else {
            $('div.navbar-collapse').removeClass('collapse');
        }

        height = (this.window.innerHeight > 0) ? this.window.innerHeight : this.screen.height;
        height = height - topOffset;
        if (height < 1) height = 1;
        if (height > topOffset) {
            $("#page-wrapper").css("min-height", (height-35) + "px");
        }
    });
    $('#dataTable').dataTable();

    bn=$("body"), cl = "click";
    $(bn).on(cl, ".upload_image", function() {
        img_container = $(this).closest('.row').find("img");
        $('#ajax').removeClass('hidden');
    }).on(cl, ".upload_doc", function() {
        img_container = $(this).closest('.row').find("i");
        $('#ajax_doc').removeClass('hidden');
    })
        .on(cl, ".select_image", function() {
        $(img_container).attr('src' ,  $(this).attr('src'));
        inp=$(img_container).closest('.row').find("input[type='hidden']");
        src=$(this).attr('src');
        src = src.substring(src.lastIndexOf('/')+ 1);
        if($(inp).length > 0 ){
            $(inp).val( src);
        }else{
            var hiddenField = document.createElement("input");
                hiddenField.setAttribute("type", "hidden");
                hiddenField.setAttribute("name", 'sub_image[image][]');
                hiddenField.setAttribute("value", src);
                $(img_container).after(hiddenField);

        }
        return false;  
    })
        .on(cl,'.select_doc',function(){
            inp=$(img_container).closest('.row').find("input[type='hidden']");
            $(inp).val($(this).data('src'));
            $exe = $(this).data('src').split('.');
            switch ($exe[$exe.length-1]){
                case 'pdf':clas = "pdf-";break;
                case 'doc':
                case 'docx':clas = "word-";break;
                case 'xlsx':clas = "excel-";break;
                default :clas = "";break;
            }
            $(img_container).removeClass("fa-file-o fa-file-pdf-o fa-file-word-o fa-file-excel-o     ");
            $(img_container).addClass("fa-file-"+clas+"o");
            $(img_container).closest('.thumbnail').find("span").html($(this).data('src'));
        })
        .on(cl, ".img_remove", function() {$(this).closest('col-lg-2').remove();})
        .on( cl,'.clear_image' , function(){
        row = $(this).closest('.row');
        $(row).find('img').attr('src',BASE_URL+'/assets/images/picture-01-128.png');
        $(row).find("input[type='hidden']").val('');
        return false;
    } )
        .on(cl,'.addMore_image',function(){
    var html = '<div class="col-md-2 left MB5 ui-state-default ">'+
        '<div class="img-thumbnail">'+
            '<div class="row">'+
                '<div class="col-sm-12">'+
                    '<img width="128" height="128" rel="lightbox" title="imaget" class="img-rounded img-responsive upload_image" alt="Image" src="'+BASE_URL+'assets/images/picture-01-128.png">'+

                    '</div>'+
                    '<div class="col-xs-offset-2">'+
                       ' <a role="button" href="#" class="btn btn-primary btn-xs upload_image ">Browse</a>'+
                       ' <a role="button" href="#" class="btn btn-default btn-xs remove_image">Clear </a>'+
                    '</div>'+
                '</div>'+
           '</div>'+
            '</div>';
    $(this).closest('.col-lg-2').after(html);
    })
        .on(cl,'.remove_image',function(){
        $(this).closest('.col-md-2').remove();
    })
        .on(cl,'.remove_video',function(){
        $(this).closest('tr').remove();
        updateTableRow('#add_new_row');
    })
        .on(cl,"#add_new_row",function(){
            var html = '<tr   >'+
                '<td class="row_id" ></td>'+
                '<td><input type="text" class="form-control" placeholder="Video URL" value="" name="video[url][]"></td>'+
                '<td><button type="button" class=" check_video btn btn-success">Check</button></td>'+
                '<td><button type="button" class=" remove_video btn btn-danger">Remove</button></td>'+
                ' </tr>';
            $(this).closest('tr').after(html);
            updateTableRow(this);
        })
        .on(cl,'.delete_btn',function(e){
            e.preventDefault();
        return confirm( '<div class="text-danger text-center " >' +
            '<h1>Are you Sure !!! </h1> ' +
            '<p class="text-info" > Do you Want Delete this Record ???</p></div>  ',$(this));
    })
        .on(cl,".btn-circle-custom",function(){img_container = null;$('#ajax,#ajax_doc').addClass('hidden');})
        .on(cl,'.check_video',function(){
            var url = $(this).closest('tr').find('input[type="text"]').val();
            if(validYT(url) ){
                url = url.replace(new RegExp("watch\\?v=", "i"), 'v/');
                url += '?fs=1&autoplay=1';
                $.fancybox.open({
                    maxWidth    : 800,
                    maxHeight   : 600,
                    fitToView   : false,
                    width       : '70%',
                    height      : '70%',
                    autoSize    : false,
                    closeClick  : false,
                    openEffect  : 'elastic',
                    closeEffect : 'none',
                    type: 'iframe',
                    href : url
                });
            }else{
                alert("<h3 class='text-danger' >Invalid Youtube URL!!!</h3>");
            }

        }).on(cl,'.remove',function(){
            if($(this).closest('tr').hasClass('main_experence')){
                $(this).closest('tr').replaceWith($(this).closest('tr').clone());
                $(this).closest('tr').find("input:text").val("");
            }else
                $(this).closest('tr').remove();
        })
        .on(cl,".add_more_sub_image",function(){
            var html = '<tr   >'+
                '<td class="row_id" ></td>'+
                '<td style="width: 20%"  >' +
                '<div class="img-thumbnail">'+
                '<div class="row">'+
                '<div class="col-sm-12">'+
                '<img width="128" height="128" rel="lightbox" title="imaget" class="img-rounded img-responsive upload_image" alt="Image" src="'+BASE_URL+'assets/images/picture-01-128.png">'+

                '</div>'+
                '<div class="col-xs-offset-2">'+
                ' <a role="button" href="#" class="btn btn-primary btn-xs upload_image ">Browse</a>'+
                ' <a role="button" href="#" class="btn btn-default btn-xs remove_image">Clear </a>'+
                '</div>'+
                '</div>'+
                '</div>'+
                '</td>'+
                '<td><input type="text" class="form-control" placeholder="Image Title" value="" name="sub_image[title][]"></td>'+
                '<td><button type="button" class=" remove_video btn btn-danger">Remove</button></td>'+
                ' </tr>';
            $(this).closest('tr').after(html);
            updateTableRow(this);
        })
        .on(cl,".add_more_sub_video",function(){
            var html = '<tr   >'+
                '<td class="row_id" ></td>'+
                '<td><input type="text" class="form-control" placeholder="Video URL" value="" name="video[url][]"></td>'+
                '<td><input type="text" class="form-control" placeholder="Video Title" value="" name="video[title][]"></td>'+
                '<td><button type="button" class=" check_video btn btn-success">Check</button></td>'+
                '<td><button type="button" class=" remove_video btn btn-danger">Remove</button></td>'+
                ' </tr>';
            $(this).closest('tr').after(html);
            updateTableRow(this);
        })
        .on (cl , ".ajax_cat_result li", function(){
        input = " <div class='result_div' id='new_product_"+$(this).data('id')+"' > "+$(this).html()+" " +
            "<input type='hidden' name='menu[]' value='"+ $(this).data('id') +"' >" +
            "<input type='hidden' name='menu_name[]' value='"+ $(this).html() +"' >" +
            " <i class=' pull-right fa-2x text-danger fa fa-times'></i> </div> ";
        $('.link').find("#new_product_"+$(this).data('id')).remove();
        $('.link').append(input);
    })
    ;

    $('.price').blur(function(){
        $(this).val(accounting.formatMoney($(this).val(), "", 2, ",", "."));
    });
    $('#upload_doc').submit(function(){
        formUrl = $(this).attr('action');
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: formUrl,
            type: 'POST',
            data: formData,
            mimeType: "multipart/form-data",
            contentType: false,
            cache: false,
            processData: false,
            dataType : "JSON",
            xhr: function(){
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt){
                    if (evt.lengthComputable) {
                        console.log(evt.lengthComputable);
                        console.log(evt.loaded);
                        console.log(evt.total);
                        var percentComplete = evt.loaded / evt.total *100 ;
                        $('.progress').removeClass('hidden');
                        $('.progress-bar').css('width',percentComplete+"%");
                    }
                }, false);
                return xhr;
            },
            success: function(data, textSatus, jqXHR){
               location.reload();
            },
            error: function(jqXHR, textStatus, errorThrown){
                //handle here error returned
            }
        });
        return false;
    });
    $( "#cat_link" ).keyup(function() {
        str = $(this);
        if($(str).val().length > 0 ){
            $.ajax( {
                url:  URL.base+"admin/menu/getData/"+$(str).val() ,dataType : "JSON"
            }).done(function() {
                    $(str).closest('div').find('.loader').removeClass('hidden');
                }).always(function(msg) {
                    if(msg == null ){
                        $(str).closest('div').find('.loader').addClass('hidden');
                    }else if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].title+"</li>"
                        });
                        $(str).closest('div').find('.loader').addClass('hidden');
                        $('.ajax_cat_result').empty().removeClass('hidden').append(li);
                    }
                });
        }else {
            $('.ajax_cat_result').empty().addClass('hidden');
        }
    });
    $('#brand_link').keyup(function(){
        str = $(this);
        if($(str).val().length > 0 ){
            $.ajax(  {
                url:  getUrl()+"/brand/getData/"+$(str).val() ,dataType : "JSON"
            }).done(function() {
                    $(str).closest('div').find('.loader').removeClass('hidden');
                }).always(function(msg) {
                    $(str).closest('div').find('.loader').addClass('hidden');
                    if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].name+"</li>"
                        });
                        $('.ajax_brand_result').empty().removeClass('hidden').append(li);
                    }
                });
        }else {
            $('.ajax_brand_result').empty().addClass('hidden');
        }
    });
    $('#pro_link').keyup(function(){
        str = $(this);
        if($(str).val().length > 0 ){
            $.ajax( {
                url:  getUrl()+"/product/getData/"+$(str).val() ,dataType : "JSON"
            }).done(function() {
                    $(str).closest('div').find('.loader').removeClass('hidden');
                }).always(function(msg) {
                    $(str).closest('div').find('.loader').addClass('hidden');
                    if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].name+"</li>"
                        });
                        $('.ajax_pro_result').empty().removeClass('hidden').append(li);
                    }
                });
        }else {
            $('.ajax_pro_result').empty().addClass('hidden');
        }
    });
    $('#best_seller_').keyup(function(){
        str = $(this);
        if($(str).val().length > 0 ){
            $.ajax( {
                url:  getUrl()+"/Product/getData/"+$(str).val() ,dataType : "JSON"
            }).done(function() {
                    $(str).closest('div').find('.loader').removeClass('hidden');
                }).always(function(msg) {
                    $(str).closest('div').find('.loader').addClass('hidden');
                    if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].name+"</li>"
                        });
                        $('.best_seller_result').empty().removeClass('hidden').append(li);
                    }
                });
        }else {
            $('.best_seller_result').empty().addClass('hidden');
        }
    });
    $('#new_product_').keyup(function(){
        str = $(this);
        if($(str).val().length > 0 ){
            $.ajax( {
                url:  getUrl()+"/Product/getData/"+$(str).val() ,dataType : "JSON"
            }).done(function() {
                    $(str).closest('div').find('.loader').removeClass('hidden');
                }).always(function(msg) {
                    $(str).closest('div').find('.loader').addClass('hidden');
                    if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].name+"</li>"
                        });
                        $('.new_product_result').empty().removeClass('hidden').append(li);
                    }
                });
        }else {
            $('.new_product_result').empty().addClass('hidden');
        }
    });
    $( ".sortable" ).sortable({opacity: 0.6, cursor: 'move'});
    $('.video_panel').sortable({opacity: 0.6, cursor: 'move', update: function (){ updateTableRow('#add_new_row'); }} );
    $( ".sortable,.video_panel" ).disableSelection();
    productLink();
    productlist();
    removeLink();
});

function productLink(){
    $('.product_link').keyup(function(){
        $this = $(this);
        if($this.val().length > 0 ){
            $.ajax({
                url : URL.current + "/getData/" + $this.val(),
                datatype : "JSON",
                success : function (msg){
                    msg = $.parseJSON(msg);
                    if(msg == null ){
                        $($this).closest('div').find('.loader').addClass('hidden');
                    }else if( msg.length > 0 ){
                        li='';
                        $.each(msg, function (i, value) {
                            li += "<li data-id='"+msg[i].id+"' >"+msg[i].title+"</li>"
                        });
                        $($this).closest('div').find('.loader').addClass('hidden');
                        $('#'+$this.data('for')).empty().removeClass('hidden').append(li);
                    }
                }
            });
        }else{
            $('#'+$this.data('for')).empty().addClass('hidden');
        }
    });
}
function productlist(){
    $('body').on('click','#feature_product>li , #best_seller>li',function(){
        id = $(this).closest('ul').attr('id');
        input = " <div class='result_div' id='"+id+"_"+$(this).data('id')+"' > "+$(this).html()+" " +
        "<input type='hidden' name='"+id+"[]' value='"+ $(this).data('id') +"' >" +
        "<input type='hidden' name='"+id+"_name[]' value='"+ $(this).html() +"' >" +
        " <i class=' pull-right fa-2x text-danger fa fa-times'></i> </div> ";
        $("."+id).find("#"+id+"_"+$(this).data('id')).remove();
        $("."+id).append(input);
    });
}
function removeLink(){
    $('body').on('click','.result_div>i.fa-times',function(){
        $(this).closest('.result_div').remove();
    });
}

var alert = function(mge){
    bootbox.alert(mge, function() {});
} ;
var confirm = function(mge,obj){
    bootbox.confirm(mge, function(result) {
        if(result) $(obj).closest('form').submit()
    });
};
function updateTableRow(tables){
    $('#'+$(tables).closest('table').attr('id') +" .row_id " ).each(function (i, row) {
        $(this).html(i+1);
    });
}
function include(url){
    document.write('<script type="text/javascript" src="'+ url +'" ></script>');
}


function getUrl() {
    return document.URL.substring(document.URL.indexOf(".com"), document.URL)+".com/admin";
}
function exe(functionName) {
    var args = [].slice.call(arguments).splice(1);
    return window[functionName].apply(this, args);
}
function login(){
    if(arguments[0] )
        window.location.href = getUrl();
    else{
        $('#password').val('');
        er_msg= '<div id="error" class="text-center text-danger"  >Invalid Username or Password <i class=" fa fa-frown-o" ></i> </div>';
        er=$('#error');
        if($(er).length > 0){
            $(er).html(er_msg);
        }else
            $('.form').before(er_msg);
        $('.loader').addClass('hidden');
    }

}
function menuAdd(){
    if(arguments[0]){

    }
}
interact('#ajax,#ajax_doc')
    .draggable({
        max: Infinity,
        onmove: function (event) {
            var target = event.target,
                x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
                y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;
            target.style.webkitTransform =
                target.style.transform =
                    'translate(' + x + 'px, ' + y + 'px)';
            target.setAttribute('data-x', x);
            target.setAttribute('data-y', y);
        },
        onend: function (event) {
        }
    })
    .inertia(true)
    .restrict({
        drag: "parent",
        endOnly: true,
        elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
    })
;
interact.maxInteractions(Infinity);
function loadDoc(){
    $.ajax( {
        url:  getUrl()+"/Upload/getDoc" ,dataType : "JSON"
    }).done(function() {
        }).always(function(msg) {
                $.each(msg, function (i, value) {
                    switch (msg[i].ext){
                        case 'pdf':clas = "pdf";break;
                        case 'doc':
                        case 'docx':clas = "word";break;
                        case 'xlsx':clas = "excel";break;
                        default :clas = "file";break;
                    }
                   $('.doc').append( '<div class="col-lg-3 col-md-4 col-xs-6 thumb select_doc " data-src="'+ msg[i].name +'" >'+
                       '<a class="thumbnail" href="#">'+
                        '<i class=" fa fa-4x fa-file-'+clas+'-o" ></i>'+
                       msg[i].name+
                    '</a>'+
                    '</div>');
                });
        });

}
function validYT(url) {
    var p = /^(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?(?=.*v=((\w|-){11}))(?:\S+)?$/;
    return (url.match(p)) ? true : false;
}

//function executeFunctionByName(functionName, context /*, args */) {
//    var args = [].slice.call(arguments).splice(2);
//    var namespaces = functionName.split(".");
//    var func = namespaces.pop();
//    for(var i = 0; i < namespaces.length; i++) {
//        context = context[namespaces[i]];
//    }
//    return context[func].apply(this, args);
//}
//executeFunctionByName("My.Namespace.functionName", window, arguments);
//
//executeFunctionByName("Namespace.functionName", My, arguments);
