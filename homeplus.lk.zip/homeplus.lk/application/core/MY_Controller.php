<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/8/15
 * Time: 11:03 AM
 */

class MY_Controller extends CI_Controller{

    public function __construct(){
        parent::__construct();
        define("IMAGE",base_url()."images/");
        define("CSS",base_url()."css/");
        define("JS",base_url()."js/");
        define('UPLOAD',base_url() . 'uploads/');
        define('UPLOAD_THUMBS',base_url() . 'uploads/thumbs/');
        $this->load->library('encrypt');
    }

    function getMenu(){
        $this->load->model('Menu_m','menu');
        $menus = $this->menu->getActive();
        foreach ($menus as $menu ){
            $this->menu->createNav($menu,$menu->id);
        }
        return $menus;
    }


    function _getProducts($objs){
        $a = array();
        foreach($objs as $k){
            $obj = $this->product->getById($k->pid);
            if(is_object($obj))
                $a[] = $obj;
        }
        return $a;
    }
}