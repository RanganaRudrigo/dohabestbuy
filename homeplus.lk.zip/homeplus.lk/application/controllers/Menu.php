<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/12/15
 * Time: 1:21 PM
 */

class Menu extends MY_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Menu_m','menu');
        $this->load->model('Product_m','product');
    }

    function index($id){

        $id = $this->encrypt->myDecode($id) ;
        $id = explode('-',$id);
        if($id[0] == 'm'){
            $this->_menu($id[1]);
        }else if ($id[0] == 'P'){
            $this->_product($id[1]);
        }else{
        //    show_404();
        }
    }

    function _menu($id){

        $obj = $this->menu->getById($id);
        if(is_object($obj)){
            $d['menu'] = $obj ;
            $d['menus'] = $this->menu->getMenu();
            $d['submenus'] = $this->menu->getActive($id);
            $d['nav'] = $this->_nav($obj);
            $d['bestseller'] = $this->product->get_best_seller();
            $d['products'] = $this->product->getByMainId($id);
            $d['view'] = 'product';
            $this->load->view('product',$d);
        }else{
            show_404();
        }
    }

    function _nav($obj){
        $array =  array(array('id'=>$obj->id , 'name' => $obj->title , 'url' => url_title($obj->title) ));
        if($obj->menu_id == 0 )
            return $array;
        else
            $this->menu->findRoot($array,$obj->menu_id);
        $array =  array_reverse($array);

        foreach($array as $k => $obj ):
            if($k==0 )
                $nav[] = array_merge($obj,array('url'=>  url_title($obj['name'])  ));
            else{
                $url='';
                for($i=$k-1;$i>-1;$i--)
                    $url =  url_title($array[$i]['name'])."/".$url ;
                $nav[] = array_merge($obj,array('url'=>  $url.url_title($obj['name'])  ));
            }
        endforeach;
        return $nav;
    }

    function _product($id){
        $item = $this->product->getByIdFront($id);
        if(is_object($item)){
            $url = str_replace( base_url() ,'', new_current_url());
            $i = count(explode('/',$url)) - 1;
            $d['i'] = $i;
            $menu = $item->menu;
            $nav = $this->_nav($menu[$i-1]);
            $nav = array_merge($nav ,array( array('id'=>$item->id , 'name' => $item->title , 'url' => url_title($item->title) ) ) );
            $d['nav'] = $nav;
            $d['related']  = $this->product->getByMainId($menu[$i-1]->id);
            $d['bestseller'] =  $this->product->get_best_seller();
            $d['menus'] = $this->menu->getMenu();
            $d['item'] = $item ;
            $d['view'] = 'sub_product';
            $this->load->view('sub_product',$d);
        }else{
          //  show_404();
        }
    }

} 