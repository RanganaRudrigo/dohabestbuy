<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	function __construct(){
        parent::__construct();
        $this->load->model('Menu_m','menu');
        $this->load->model('Slider_m','slider');
        $this->load->model('Banner_m','banner');
        $this->load->model('Product_m','product');
    }
	public function index(){
        $d['menus'] = $this->menu->getMenu();
        $d['silder'] = $this->slider->getActive();
        $d['banner'] = $this->banner->getActive();
        $d['feature_product'] = $this->product->get_feature_product();
        $d['best_seller'] = $this->product->get_best_seller();
        $d['view'] = 'home';
		$this->load->view('inc/template',$d);
	}

    function about(){
        $d['menus'] = $this->menu->getMenu();
        $this->load->view('about_us',$d);
    }

    function contact(){
        $d['menus'] = $this->menu->getMenu();
        $this->load->view('contact_us',$d);
    }

    function gallery(){
        $this->load->model('gallery_m','gallery');
        $d['record']= $this->gallery->getActive();
        $d['menus'] = $this->menu->getMenu();

        $this->load->view('gallery',$d);
    }

}
