<?php
/**
 * Created by PhpStorm.
 * User: gowtham
 * Date: 5/11/15
 * Time: 8:11 AM
 */

class Home extends CI_Controller {
    function __construct(){
        parent::__construct();
    }
    function login(){
        $d['error'] ="";
        $this->form_validation->set_rules('name','','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run()){
            $this->load->model('user_m','user');
            if($this->user->login()){
                redirect(current_url());
            }else{
                $d['error'] = "<div  class='text-center text-danger'>Invalid Username or Password <i class=' fa fa-frown-o'></i> </div>";
            }
        }else{
            $this->session->sess_destroy();
            $this->load->view('admin/includes/header');
            $this->load->view('admin/login',$d);
            $this->load->view('admin/includes/footer');
        }

    }
    function index(){

        if($this->input->post('logout')){
            $this->session->sess_destroy();
            redirect(current_url());
        }

        if($this->session->userdata('id') == FALSE){
            $this->login();
        }else{
            $d['view'] = 'home';
            $this->load->view('admin/includes/template.php',$d);
        }

    }
}