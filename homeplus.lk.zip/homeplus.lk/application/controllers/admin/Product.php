<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 12:32 PM
 */


class Product extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Product_m','product');
    }
    function index($id=0){
        $this->form_validation->set_rules('id','','required');
        if($this->form_validation->run()){
            $this->product->update();
            redirect(current_url());
        }
        $d['record']= $this->product->getActive($id);
        $d['view'] = 'product/_list';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function sub_event($id=0){
        $this->index($id);
    }
    function add($id=0){
        $result = new Obj();
        $result->sub_image = array();
        $result->menu = array();
        $result->product_id = $id;
        $this->form_validation->set_rules('form[title]','Title','required');
        $this->form_validation->set_rules('form[image]','Image','required');
        $this->form_validation->set_rules('form[price]','Price','decimal');
        $this->form_validation->set_rules('form[qty]','Price','integer');
        $this->form_validation->set_rules('form[weight]','weight','integer');
        $this->form_validation->set_rules('form[discount_price]','Discount Price',"decimal|less_than[{$this->input->post('form[price]')}]");
        if($this->form_validation->run()){
            if($this->product->insert()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
            $image = $this->input->post('sub_image');
            if(empty($image)){
                $result->sub_image = array();
            }else{
                $data = array();
                foreach($image['image'] as $img)
                    array_push( $data , array('image'=>$img) );

                $result->sub_image = arrayToObject($data);
            }
            $menu = $this->input->post('menu');
            $menu_name = $this->input->post('menu_name');
             if(empty($menu)){
                $result->menu = array();
            }else{
                $data = array();
                foreach($menu as $k => $v)
                    array_push( $data , array('m_id'=>$v , 'name' => $menu_name[$k] ) );

                $result->menu = arrayToObject($data);
            }

        }
        $result->weight_array = arrayToObject(
            array(
                array('id'=>1 , 'name'=> 'milligram'),
                array('id'=>2 , 'name'=> 'gram'),
                array('id'=>3 , 'name'=> 'kilogram'),
                array('id'=>4 , 'name'=> 'pounds'),
            )
        );
        $last = $this->product->getLast();
        if(empty($last->id))    $result->code ="PRO00001" ;
        else   $result->code = "PRO".repeater(0,5-strlen( $last->id)).( (int)$last->id+1 );
        $d['result'] = $result;
        $d['view'] = 'product/_form';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function update($id){

        $this->form_validation->set_rules('form[title]','Title','required');
        if($this->form_validation->run()){
            if($this->product->update()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
            $image = $this->input->post('sub_image');
            if(empty($image)){
                $record->sub_image = array();
            }else{
                $data = array();
                foreach($image['image'] as $img)
                    array_push( $data , array('image'=>$img) );

                $record->sub_image = arrayToObject($data);
            }
        }
		 

        $result = $this->product->getById($id);
        if(is_object($result)){
		$result->weight_array = arrayToObject(
            array(
                array('id'=>1 , 'name'=> 'milligram'),
                array('id'=>2 , 'name'=> 'gram'),
                array('id'=>3 , 'name'=> 'kilogram'),
                array('id'=>4 , 'name'=> 'pounds'),
            )
        );
		$result->status_array = arrayToObject(array(
            array('id'=>1 , 'name'=> "Active"),
            array('id'=>0 , 'name'=> "Deactive")
        ));
            $d['result'] = $result;
            $d['view'] = 'product/_form';
            $d['id'] = $id ;
            $this->load->view('admin/includes/template',$d);
        }else{
            show_404();
        }

    }
    function getData($str=""){
        echo json_encode($this->product->getByLike($str));
    }
}