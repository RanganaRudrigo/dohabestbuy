<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 4:03 PM
 */

class Order extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Product_m','product');
    }
    function index(){
        if($this->input->post('submit')==true){
            if($this->product->insertHomeScreen())
                $d['valid'] = 'Fill the Name Field !!!';
            else
                $d['error'] = 'Fill the Name Field !!!';
        }
        $d['view'] = 'order' ;
        $this->load->view('admin/includes/template',$d);
    }
    function getData($str=''){
        echo json_encode($this->product->getByLike($str));
    }
}