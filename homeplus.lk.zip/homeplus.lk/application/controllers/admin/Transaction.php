<?php
/**
 * Created by PhpStorm.
 * User: gowtham
 * Date: 5/25/15
 * Time: 2:19 PM
 */

class Transaction extends CI_Controller {

    function __construct(){
        parent::__construct();
    }
    function index(){

    }
    function view(){

    }

} 