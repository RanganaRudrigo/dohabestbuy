<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 12:13 PM
 */

class Slider extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Slider_m','slider');
    }
    function index($id=0){
        $this->form_validation->set_rules('id','','required');
        if($this->form_validation->run()){
            $this->slider->update();
            redirect(current_url());
        }

        $d['record']= $this->slider->getActive($id);
        $d['view'] = 'slider/_list';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function sub_event($id=0){
        $this->index($id);
    }
    function add($id=0){
        $result = new Obj();
        $result->slider_id = $id;
        $this->form_validation->set_rules('form[image]','Image','required');
        if($this->form_validation->run()){
            if($this->slider->insert()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
        }
        $last = $this->slider->getLast();
        if(empty($last->id))    $result->code ="SLDR0001" ;
        else   $result->code = "SLDR".repeater(0,4-strlen( $last->id)).( (int)$last->id+1 );

        $d['result'] = $result;
        $d['view'] = 'slider/_form';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function update($id){
        $this->form_validation->set_rules('form[image]','Image','required');
        if($this->form_validation->run()){
            if($this->slider->update()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
        }

        $result = $this->slider->getById($id);
        if(is_object($result)){
            $d['result'] = $result;
            $d['view'] = 'slider/_form';
            $d['id'] = $id ;
            $this->load->view('admin/includes/template',$d);
        }else{
            show_404();
        }

    }
}