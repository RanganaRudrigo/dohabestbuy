<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 11:00 AM
 */

class Menu extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Menu_m','menu');
    }
    function index($id=0){
        $this->form_validation->set_rules('id','','required');
        if($this->form_validation->run()){
            $this->menu->update();
            redirect(current_url());
        }
        $d['record']= $this->menu->getActive($id);
        $d['view'] = 'menu/_list';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function sub_event($id=0){
        $this->index($id);
    }
    function add($id=0){
        $result = new Obj();
        $result->menu_id = $id;
        $this->form_validation->set_rules('form[title]','Title','required');
        if($this->form_validation->run()){
            if($this->menu->insert()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
        }
        $last = $this->menu->getLast();
        if(empty($last->id))    $result->code ="MENU0001" ;
        else   $result->code = "MENU".repeater(0,4-strlen( $last->id)).( (int)$last->id+1 );
        $d['result'] = $result;
        $d['view'] = 'menu/_form';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function update($id){

        $this->form_validation->set_rules('form[title]','Title','required');
        if($this->form_validation->run()){
            if($this->menu->update()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
        }

        $result = $this->menu->getById($id);
        if(is_object($result)){
            $d['result'] = $result;
            $d['view'] = 'menu/_form';
            $d['id'] = $id ;
            $this->load->view('admin/includes/template',$d);
        }else{
            show_404();
        }

    }
    function getData($str){
        echo json_encode($this->menu->getByLike($str));
    }
}