<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 6/08/15
 * Time: 12:06 PM
 */


class Gallery extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('gallery_m','gallery');
        if($this->input->post('logout')){
            $this->session->sess_destroy();
            redirect(current_url());
        }
        if($this->session->userdata('id') == FALSE){
            redirect(base_url()."admin");
        }
    }
    function index($id=0){
        $this->form_validation->set_rules('id','','required');
        if($this->form_validation->run()){
            $this->gallery->update();
            redirect(current_url());
        }
        $d['record']= $this->gallery->getActive($id);
        $d['view'] = 'gallery/_list';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function sub_event($id=0){
        $this->index($id);
    }
    function add($id=0){
        $result = new Obj();
        $this->form_validation->set_rules('form[image]','Image','required');
        $this->form_validation->set_rules('form[order]','Order','integer');
        if($this->form_validation->run()){
            if($this->gallery->insert()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
            $result->size_array = $obj->size_array;
        }
        $last = $this->gallery->getLast();
        if(empty($last->id))    $result->code ="gal0001" ;
        else   $result->code = "gal".repeater(0,4-strlen( $last->id)).( (int)$last->id+1 );

        $d['result'] = $result;
        $d['view'] = 'gallery/_form';
        $d['id'] = $id ;
        $this->load->view('admin/includes/template',$d);
    }
    function update($id){
        $this->form_validation->set_rules('form[image]','Image','required');
        $this->form_validation->set_rules('form[order]','Order','integer');
        if($this->form_validation->run()){
            if($this->gallery->update()){
                $d['error'] = '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Successfully Inserted                            </div>';
            }else{
                $d['error'] = '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Record Insertion Failure     !!!                            </div>';
            }
        }else if(!empty($_POST)){
            $result = arrayToObject($this->input->post('form'));
            $result->id = $this->input->post('id');
            $obj = new Obj();
            $result->status_array = $obj->status_array;
            $result->size_array = $obj->size_array;
        }

        $result = $this->gallery->getById($id);
        if(is_object($result)){
            $obj = new Obj();
            $result->status_array = $obj->status_array;
            $result->size_array = $obj->size_array;
            $d['result'] = $result;
            $d['view'] = 'gallery/_form';
            $d['id'] = $id ;
            $this->load->view('admin/includes/template',$d);
        }else{
            show_404();
        }

    }
}