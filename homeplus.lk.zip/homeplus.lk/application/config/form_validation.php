<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 11:14 AM
 */

$config['error_prefix'] = '<small> <div class="text-danger" >';
$config['error_suffix'] = '</div> </small>';