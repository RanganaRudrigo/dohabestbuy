<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 12:33 PM
 */

class Product_m extends CI_Model {
    var $table = 'product_tab';
    function __construct(){
        parent::__construct();
    }
    function getLast(){
        return $this->db->from($this->table)->select_max('id')->where('status',1)->get()->first_row();
    }

    function getActive($id=0){
        return $this->db->from($this->table)->where('status',1)->get()->result();
    }
    function insert(){
        if( $this->db->insert($this->table , $this->input->post('form')) ){
            $id = $this->db->insert_id();
            $image = $this->input->post('sub_image');
            if(!empty($image)){
                $data = array();
                foreach($image['image'] as $img)
                    array_push( $data , array('image'=>$img , 'pid'=>$id ) );
                $this->db->insert_batch('product_image',$data );
            }
            $menu = $this->input->post('menu');
            $menu_name = $this->input->post('menu_name');
            if(!empty($menu)){
                $data = array();$a= array();
                foreach($menu as $k => $v){
                    $vs = explode('-',$v);
                    if(is_array($vs))
                        foreach($vs as $ks)
                            array_push($a, array( 'p_id'=>$id ,'m_id' => $ks ));
                    else
                        array_push($a, array( 'p_id'=>$id ,'m_id' => $v ));

                    array_push( $data , array( 'p_id'=>$id, 'm_id'=>$v , 'name' => $menu_name[$k] ) );
                }
                unique($a,'m_id');
                $this->db->insert_batch('pro_cat',$a );
                $this->db->insert_batch('product_cat',$data );
            }

            return true ;
        }
        return false ;
    }
    function getById($id){
        $q = $this->db->from($this->table)->where('id',$id)->get()->first_row();
        if(is_object($q)){
            $q->menu = $this->db->from('product_cat')->where('p_id',$id)->get()->result();
            $q->sub_image = $this->db->from('product_image')->where('pid',$id)->get()->result();
            return $q;
        }else{
            return array();
        }
    }
    function update(){
        if($this->db->update($this->table, $this->input->post('form'),array('id' => $this->input->post('id')))) {
		$this->db->delete('product_image', array('pid' => $this->input->post('id')));
        $image = $this->input->post('sub_image');
        if(!empty($image)){
            $data = array();
            foreach($image['image'] as $img)
                array_push( $data , array('image'=>$img , 'pid'=>$this->input->post('id') ) );
            $this->db->insert_batch('product_image',$data );
        }
		$this->db->delete('pro_cat', array('p_id' => $this->input->post('id')));
		$this->db->delete('product_cat', array('p_id' => $this->input->post('id')));
		$menu = $this->input->post('menu');
            $menu_name = $this->input->post('menu_name');
            if(!empty($menu)){
                $data = array();$a= array();
                foreach($menu as $k => $v){
                    $vs = explode('-',$v);
                    if(is_array($vs))
                        foreach($vs as $ks)
                            array_push($a, array( 'p_id'=>$this->input->post('id') ,'m_id' => $ks ));
                    else
                        array_push($a, array( 'p_id'=>$this->input->post('id') ,'m_id' => $v ));

                    array_push( $data , array( 'p_id'=>$this->input->post('id'), 'm_id'=>$v , 'name' => $menu_name[$k] ) );
                }
                unique($a,'m_id');
                $this->db->insert_batch('pro_cat',$a );
                $this->db->insert_batch('product_cat',$data );
            }

            return true ;
		
		}
		return false ;
        
    }
    function getByLike($str=''){
      return  $this->db->from($this->table)->where('status',1)->like('title',$str)->get()->result();
    }
    function insertHomeScreen(){
        $this->db->truncate('best_seller');
        $this->db->truncate('feature_product');
        $best_seller = array();
        $c = count($this->input->post('best_seller'));
        $a = $this->input->post('best_seller');
        $best_seller_name = $this->input->post('best_seller_name');
        for($i=0;$i < $c ; $i++){
             array_push($best_seller,array('pid'=>$a[$i] , 'pname'=> $best_seller_name[$i] ));
        }
        if(!empty($best_seller))
            $this->db->insert_batch('best_seller',$best_seller);


        $feature_product = array();
        $c = count($this->input->post('feature_product'));
        $a = $this->input->post('feature_product');
        $feature_product_name = $this->input->post('feature_product_name');
        for($i=0;$i < $c ; $i++){
             array_push($feature_product,array('pid'=>$a[$i] , 'pname'=>$feature_product_name[$i]));
        }
        if(!empty($feature_product))
            $this->db->insert_batch('feature_product',$feature_product);
        return true;
    }
    function get_best_seller(){
        $feature = $this->db->get('best_seller');
        foreach($feature->result() as $obj){
            $d[] = $obj->pid ;
        }
        if(isset($d)){
            return $this->db->from($this->table)->where_in('id',$d)->get()->result();
        }
        return array();
    }
    function get_feature_product(){
        $feature = $this->db->get('feature_product');
        foreach($feature->result() as $obj){
            $d[] = $obj->pid ;
        }
        if(isset($d)){
            return $this->db->from($this->table)->where_in('id',$d)->get()->result();
        }
        return array();
    }
    function getByMainId($mid){
        $menus = $this->db->from('pro_cat')->where('m_id',$mid)->get();
        foreach($menus->result() as $menu){
            $d[] = $menu->p_id ;
        }
        if(isset($d))
            return $this->db->from($this->table)->where('status',1)->where_in('id',$d)->get()->result();
        else
            return array();
    }
    function getByIdFront($id){
        $q = $this->db->from($this->table)->where('id',$id)->where('status',1)->get()->first_row();
        if(is_object($q)){
            $menus = $this->db->select('m_id')->from('pro_cat')->where('p_id',$id)->get();
            foreach($menus->result() as $r ){
                $d[] = $r->m_id;
            }
            if(isset($d) ){
                $q->menu =  $this->menu->getMenuBySort($d);
            }else{
                $q->menu  = null ;
            }
            $q->sub_image = $this->db->from('product_image')->where('pid',$id)->get()->result();
            return $q;
        }else{
            return array();
        }
    }
} 