<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 5/11/15
 * Time: 11:02 AM
 */

class Menu_m extends CI_Model {
    var $table = 'menu_tab';
    function __construct(){
        parent::__construct();
    }
    function getLast(){
        return $this->db->from($this->table)->select_max('id')->where('status',1)->get()->first_row();
    }

    function getActive($id=0){
        return $this->db->from($this->table)->where('menu_id',$id)->where('status',1)->get()->result();
    }
    function insert(){
       return  $this->db->insert($this->table , $this->input->post('form')) ? true : false;
    }
    function getById($id){
        return $this->db->from($this->table)->where('id',$id)->get()->first_row();
    }
    function update(){
        return $this->db->update($this->table, $this->input->post('form'),array('id' => $this->input->post('id')));
    }
    function getByLike($str=""){
        $q = $this->db->from($this->table)->where('status',1)->like('title',$str)->get();
        if($q->num_rows() < 1 )
            return null;
        foreach($q->result() as $r ){
            if($r->menu_id != 0){
                $this->getRoot($r , $r->menu_id );
            }
            $d[] = $r;
        }
        return $d;
    }
    function getRoot(&$r,$m_id=0){
       $q = $this->db->from($this->table)->where('id',$m_id)->get()->first_row();
        if(is_object($q)){
            $r->id .= "-".$q->id;
            $r->title = $q->title ." > " .$r->title;
            if($q->menu_id != 0 ){
                $this->getRoot($r,$q->menu_id);
            }
        }
    }
    function getMenu(){
        $menus = $this->db->from($this->table)->where('status',1)->where('menu_id',0)->get()->result();
        foreach($menus as $menu ){
            $menu->submenu = $this->db->from($this->table)->where('status',1)->where('menu_id',$menu->id)->get()->result();
        }
        return $menus;
    }


    function createNav(&$r,$id=0){
        $q = $this->db->from($this->table)->where('menu_id',$id)->where('status',1)->get()->result();
        if( is_array($q) && !empty($q)){
            foreach($q as $n)
                if($n->menu_id != 0 )
                    $this->createNav($n,$n->id);
            $r->submenu = $q;
        }
    }
    function findRoot(&$array,$id){
        $q = $this->db->from($this->table)->where('id',$id)->where('status',1)->get()->first_row();
        if(is_object($q)){
            array_push($array,array('id'=>$q->id , 'name' => $q->title ));
            if($q->menu_id != 0 )
                $this->findRoot($array,$q->menu_id);
        }
    }
    function getMenuBySort($ids){
        return $this->db->select('id,title,menu_id')->from($this->table)->where_in('id',$ids)->where('status',1)->order_by('menu_id')->get()->result();
    }
}