<?php
/**
 * Created by PhpStorm.
 * User: gowtham
 * Date: 5/11/15
 * Time: 8:19 AM
 */

class User_m extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function login(){
        $q = $this->db->get_where('user_tab',array('name' => $this->input->post('name') , 'password'=>sha1($this->input->post('password'))  ));
        if($q->num_rows() > 0 ){
            foreach($q->result() as $r ){
                $user = array(
                    'id'=>$r->id,
                    'name'=>$r->name
                );
                $this->session->set_userdata($user);
                return true;
            }
            return false;
        }
    }
}