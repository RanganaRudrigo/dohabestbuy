<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 8/23/15
 * Time: 11:28 AM
 */


class Gallery_m extends CI_Model {
    var $table = 'gallery_tab';
    function __construct(){
        parent::__construct();
    }
    function getLast(){
        return $this->db->from($this->table)->select_max('id')->where('status',1)->get()->first_row();
    }
    function getActive($id=0){
        return $this->db->from($this->table)->where('status',1)->get()->result();
    }
    function insert(){
        return  $this->db->insert($this->table , $this->input->post('form')) ? true : false;
    }
    function getById($id){
        return $this->db->from($this->table)->where('id',$id)->get()->first_row();
    }
    function update(){
        return $this->db->update($this->table, $this->input->post('form'),array('id' => $this->input->post('id')));
    }
    function limit($l=0){
        $this->db->from($this->table)->where('status',1);
        if($l) $this->db->limit($l);
        return $this->db->get()->result();
    }
}