<!DOCTYPE HTML>

<html lang="en-us"  class="default" >

<head>
<meta charset="utf-8" />
<title>Home Plus</title>

<meta name="viewport" content="width=device-width, minimum-scale=0.25, maximum-scale=1.6, initial-scale=1.0" />
<meta name="apple-mobile-web-app-capable" content="yes" />

<link rel="shortcut icon" type="image/x-icon" href="" />

<link rel="stylesheet" href="<?=CSS?>global.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>uniform.default.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>jquery.fancybox.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>product_list.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockcart.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockcategories.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockcurrencies.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blocklanguages.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockcontact.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blocknewsletter.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>jquery.autocomplete.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blocksearch.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockspecials.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockuserinfo.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>homeslider.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>hooks.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>productcomments.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>styles.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>paneltool.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>colorpicker.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>megamenu.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>owl.carousel.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>owl.theme.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>typo.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blockwishlist.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>blogcarousel.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>leoblog.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>leocustomajax.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>product.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?=CSS?>productscategory.css" type="text/css" media="all" />

<script type="text/javascript">
    var CUSTOMIZE_TEXTFIELD = 1;
    var FancyboxI18nClose = 'Close';
    var FancyboxI18nNext = 'Next';
    var FancyboxI18nPrev = 'Previous';
    var PS_CATALOG_MODE = false;
    var added_to_wishlist = 'Added to your wishlist.';
    var ajax_allowed = true;
    var ajaxsearch = true;
    var allowBuyWhenOutOfStock = false;
    var attribute_anchor_separator = '-';
    var attributesCombinations = [{"id_attribute":"1","id_attribute_group":"1","attribute":"s","group":"size"},{"id_attribute":"16","id_attribute_group":"3","attribute":"yellow","group":"color"},{"id_attribute":"14","id_attribute_group":"3","attribute":"blue","group":"color"},{"id_attribute":"13","id_attribute_group":"3","attribute":"orange","group":"color"},{"id_attribute":"11","id_attribute_group":"3","attribute":"black","group":"color"},{"id_attribute":"2","id_attribute_group":"1","attribute":"m","group":"size"},{"id_attribute":"3","id_attribute_group":"1","attribute":"l","group":"size"}];
    var availableLaterValue = '';
    var availableNowValue = 'In stock';
    var baseDir = '';
    var baseUri = '';
    var blocksearch_type = 'top';
    var combinations = {"21":{"attributes_values":{"1":"S","3":"Orange"},"attributes":[1,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','13'"},"20":{"attributes_values":{"1":"S","3":"Blue"},"attributes":[1,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','14'"},"19":{"attributes_values":{"1":"S","3":"Yellow"},"attributes":[1,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','16'"},"22":{"attributes_values":{"1":"S","3":"Black"},"attributes":[1,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','11'"},"26":{"attributes_values":{"1":"M","3":"Black"},"attributes":[2,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','11'"},"25":{"attributes_values":{"1":"M","3":"Orange"},"attributes":[2,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','13'"},"24":{"attributes_values":{"1":"M","3":"Blue"},"attributes":[2,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','14'"},"23":{"attributes_values":{"1":"M","3":"Yellow"},"attributes":[2,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','16'"},"27":{"attributes_values":{"1":"L","3":"Yellow"},"attributes":[3,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','16'"},"30":{"attributes_values":{"1":"L","3":"Black"},"attributes":[3,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','11'"},"29":{"attributes_values":{"1":"L","3":"Orange"},"attributes":[3,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','13'"},"28":{"attributes_values":{"1":"L","3":"Blue"},"attributes":[3,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','14'"}};
    var combinationsFromController = {"21":{"attributes_values":{"1":"S","3":"Orange"},"attributes":[1,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','13'"},"20":{"attributes_values":{"1":"S","3":"Blue"},"attributes":[1,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','14'"},"19":{"attributes_values":{"1":"S","3":"Yellow"},"attributes":[1,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','16'"},"22":{"attributes_values":{"1":"S","3":"Black"},"attributes":[1,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'1','11'"},"26":{"attributes_values":{"1":"M","3":"Black"},"attributes":[2,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','11'"},"25":{"attributes_values":{"1":"M","3":"Orange"},"attributes":[2,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','13'"},"24":{"attributes_values":{"1":"M","3":"Blue"},"attributes":[2,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','14'"},"23":{"attributes_values":{"1":"M","3":"Yellow"},"attributes":[2,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'2','16'"},"27":{"attributes_values":{"1":"L","3":"Yellow"},"attributes":[3,16],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','16'"},"30":{"attributes_values":{"1":"L","3":"Black"},"attributes":[3,11],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','11'"},"29":{"attributes_values":{"1":"L","3":"Orange"},"attributes":[3,13],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','13'"},"28":{"attributes_values":{"1":"L","3":"Blue"},"attributes":[3,14],"price":0,"specific_price":{"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"},"ecotax":0,"weight":0,"quantity":300,"reference":null,"unit_impact":"0.000000","minimal_quantity":"1","available_date":"","id_image":-1,"list":"'3','14'"}};
    var comparator_max_item = 3;
    var comparedProductsIds = [];
    var confirm_report_message = 'Are you sure you want report this comment?';
    var contentOnly = false;
    var currencyBlank = 0;
    var currencyFormat = 1;
    var currencyRate = 1;
    var currencySign = '$';
    var currentDate = '2015-04-04 21:36:44';
    var customerGroupWithoutTax = true;
    var customizationFields = false;
    var customizationIdMessage = 'Customization #';
    var default_eco_tax = 0;
    var delete_txt = 'Delete';
    var displayDiscountPrice = '0';
    var displayList = true;
    var displayPrice = 1;
//    var doesntExist = 'This combination does not exist for this product. Please select another combination.';
//    var doesntExistNoMore = 'This product is no longer in stock';
//    var doesntExistNoMoreBut = 'with those attributes but is available with others.';
    var ecotaxTax_rate = 0;
    var fieldRequired = 'Please fill in all the required fields before saving your customization.';
    var freeProductTranslation = 'Free!';
    var freeShippingTranslation = 'Free shipping!';
    var generated_date = 1428197804;
    var group_reduction = 0;
    var idDefaultImage = 102;
    var id_lang = 1;
    var id_product = 5;
    var img_dir = 'images/';
    var img_prod_dir = 'images/p/';
    var img_ps_dir = 'images/';
    var instantsearch = false;
    var isGuest = 0;
    var isLogged = 0;
    var isMobile = false;
    var jqZoomEnabled = false;
    var loggin_required = 'You must be logged in to manage your wishlist.';
    var maxQuantityToAllowDisplayOfLastQuantityMessage = 3;
    var max_item = 'You cannot add more than 3 product(s) to the product comparison';
    var min_item = 'Please select at least one product';
    var minimalQuantity = 1;
    var moderation_active = true;
    var mywishlist_url = '';
    var noTaxForThisProduct = true;
    var oosHookJsCodeFunctions = [];
    var page_name = 'product';
    var placeholder_blocknewsletter = 'Enter your e-mail';
    var priceDisplayMethod = 1;
    var priceDisplayPrecision = 2;
    var productAvailableForOrder = true;
    var productBasePriceTaxExcl = 30.506321;
    var productBasePriceTaxExcluded = 30.506321;
    var productHasAttributes = true;
    var productPrice = 28.98;
    var productPriceTaxExcluded = 30.506321;
    var productPriceWithoutReduction = 30.506321;
    var productReference = '<?=$item->code?>';
    var productShowPrice = true;
    var productUnitPriceRatio = 0;
    var product_fileButtonHtml = 'Choose File';
    var product_fileDefaultHtml = 'No file selected';
    var product_specific_price = {"id_specific_price":"1","id_specific_price_rule":"0","id_cart":"0","id_product":"5","id_shop":"0","id_shop_group":"0","id_currency":"0","id_country":"0","id_group":"0","id_customer":"0","id_product_attribute":"0","price":"-1.000000","from_quantity":"1","reduction":"0.050000","reduction_tax":"1","reduction_type":"percentage","from":"0000-00-00 00:00:00","to":"0000-00-00 00:00:00","score":"32"};
    var productcomment_added = 'Your comment has been added!';
    var productcomment_added_moderation = 'Your comment has been added and will be available once approved by a moderator';
    var productcomment_ok = 'OK';
    var productcomment_title = 'New comment';
    var productcomments_controller_url = '';
    var productcomments_url_rewrite = false;
    var quantitiesDisplayAllowed = true;
    var quantityAvailable = 3600;
    var quickView = true;
    var reduction_percent = 5;
    var reduction_price = 0;
    var removingLinkText = 'remove this product from my cart';
    var roundMode = 2;
    var search_url = '';
    var secure_key = '605fc1fd10dfbe95782621d3dc7f1609';
    var sharing_img = 'images/102.jpg';
    var sharing_name = 'Printed Summer Dress';
    var sharing_url = '';
    var specific_currency = false;
    var specific_price = -1;
    var static_token = 'b780f4fb17b185b4b307d81526c2320c';
    var stf_msg_error = 'Your e-mail could not be sent. Please check the e-mail address and try again.';
    var stf_msg_required = 'You did not fill required fields';
    var stf_msg_success = 'Your e-mail has been sent successfully';
    var stf_msg_title = 'Send to a friend';
    var stf_secure_key = '5e24bf3e3b3212772a347745e55c171b';
    var stock_management = 1;
    var taxRate = 0;
    var token = 'b780f4fb17b185b4b307d81526c2320c';
    var upToTxt = 'Up to';
    var uploading_in_progress = 'Uploading in progress, please be patient.';
    var usingSecureMode = false;
    var wishlistProductsIds = false;
</script>

<script type="text/javascript" src="<?=JS?>jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="<?=JS?>jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.easing.js"></script>
<script type="text/javascript" src="<?=JS?>tools.js"></script>
<script type="text/javascript" src="<?=JS?>global.js"></script>
<script type="text/javascript" src="<?=JS?>10-bootstrap.min.js"></script>
<script type="text/javascript" src="<?=JS?>15-jquery.total-storage.min.js"></script>
<script type="text/javascript" src="<?=JS?>15-jquery.uniform-modified.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.fancybox.js"></script>
<script type="text/javascript" src="<?=JS?>products-comparison.js"></script>
<script type="text/javascript" src="<?=JS?>ajax-cart.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.scrollTo.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.serialScroll.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.bxslider.js"></script>
<script type="text/javascript" src="<?=JS?>treeManagement.js"></script>
<script type="text/javascript" src="<?=JS?>blocknewsletter/blocknewsletter.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?=JS?>blocksearch.js"></script>
<script type="text/javascript" src="<?=JS?>homeslider.js"></script>
<script type="text/javascript" src="<?=JS?>script.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.cooki-plugin.js"></script>
<script type="text/javascript" src="<?=JS?>colorpicker.js"></script>
<script type="text/javascript" src="<?=JS?>paneltool.js"></script>
<script type="text/javascript" src="<?=JS?>owl.carousel.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.themepunch.enablelog.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.themepunch.revolution.js"></script>
<script type="text/javascript" src="<?=JS?>jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="<?=JS?>ajax-wishlist.js"></script>
<script type="text/javascript" src="<?=JS?>index.js"></script>
<script type="text/javascript" src="<?=JS?>leocustomajax.js"></script>
<script type="text/javascript" src="<?=JS?>product.js"></script>
<script type="text/javascript" src="<?=JS?>productcomments.js"></script>
<script type="text/javascript" src="<?=JS?>productscategory.js"></script>
<link rel="stylesheet" type="text/css" href="<?=CSS?>responsive.css"/>
<link rel="stylesheet" type="text/css" href="<?=CSS?>font-awesome.min.css"/>


<link rel="stylesheet" href="<?=CSS?>test33.css" type="text/css" media="all" />


<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<!--[if IE 8]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
</head>
<body id="product" class="product product-5 product-printed-summer-dress category-11 category-summer-dresses hide-left-column lang_en fullwidth  double-menu">
<section id="page" data-column="col-xs-12 col-sm-6 col-md-3" data-type="grid">
<!-- Header -->
<?php $this->load->view('inc/header'); ?>
<?php $this->load->view('inc/nav'); ?>




<!-- Content -->
<section id="columns" class="columns-container">
<div class="container">
<div class="row">
<div id="top_column" class="center_column col-xs-12 col-sm-12 col-md-12">

<div class="row"
    >

<div class="widget col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12"
    >

<!-- MODULE Block specials -->
<div id="leoproducttab216430965" class="products_block exclusive block nopadding">
<div class="block_content">
<ul id="productTabs" class="nav nav-pills">

    <li><a href="#leoproducttab216430965special" data-toggle="tab">Special</a></li>

    <li><a href="#leoproducttab216430965bestseller" data-toggle="tab"><span></span>Best Seller</a></li>

    <li><a href="#leoproducttab216430965featured" data-toggle="tab"><span></span>Featured Products</a></li>
</ul>

<div id="product_tab_content"><div class="product_tab_content tab-content">

<div class="tab-pane" id="leoproducttab216430965special">
<div class="carousel slide" id="leoproducttab216430965-special">

<div class="carousel-inner">
<div class="item active">
<div class="product_list grid">
<div class="row">
<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="5"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/2/102-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="5"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_5" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '5', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" data-id-product="5" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>



                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=5&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="5">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="7"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/7/87-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="7"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_7" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '7', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" data-id-product="7" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                        Printed Chiffon...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed chiffon knee length dress with tank straps. Deep v-neckline.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                    <span class="price-percent-reduction">-20%</span>


                </div>
                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=7&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="7">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="11"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/9/4/94-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="11"></span>
                </a>
										<span class="sale-box">
					<span class="sale-label product-label">Sale!</span>
				</span>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_11" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '11', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" data-id-product="11" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                        Printed Chiffon...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed chiffon knee length dress with tank straps. Deep v-neckline.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                    <span class="price-percent-reduction">-20%</span>


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=11&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="11">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="12"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=12&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/9/6/96-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="12"></span>
                </a>
										<span class="sale-box">
					<span class="sale-label product-label">Sale!</span>
				</span>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_12" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '12', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=12&amp;controller=product&amp;id_lang=1" data-id-product="12" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=12&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=12&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=12&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                        Printed Chiffon...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed chiffon knee length dress with tank straps. Deep v-neckline.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                    <span class="price-percent-reduction">-20%</span>


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=12&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="12">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 last_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="14"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=14&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/1/101-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="14"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_14" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '14', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=14&amp;controller=product&amp;id_lang=1" data-id-product="14" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=14&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=14&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=14&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$28.98						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$30.51
							</span>
                    <span class="price-percent-reduction">-5%</span>


                </div>
                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=14&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="14">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>
</div>

</div>
</div>
</div>
</div>





</div>


<div class="tab-pane" id="leoproducttab216430965bestseller">
<div class="carousel slide" id="leoproducttab216430965-bestseller">

<a class="carousel-control left" href="#leoproducttab216430965-bestseller"   data-slide="prev">&lsaquo;</a>
<a class="carousel-control right" href="#leoproducttab216430965-bestseller"  data-slide="next">&rsaquo;</a>

<div class="carousel-inner">
<div class="item active">
<div class="product_list grid">
<div class="row">
<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="1"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Faded Short Sleeve T-shirts" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/4/74-home_default.jpg" alt="Faded Short Sleeve T-shirts" title="Faded Short Sleeve T-shirts" itemprop="image" />
                    <span class="product-additional" data-idproduct="1"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_1" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '1', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" data-id-product="1" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Faded Short Sleeve T-shirts" itemprop="url" >
                        Faded Short...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Faded short sleeve t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.51						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=1&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="1">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="2"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Blouse" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/6/76-home_default.jpg" alt="Blouse" title="Blouse" itemprop="image" />
                    <span class="product-additional" data-idproduct="2"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_2" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '2', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" data-id-product="2" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Blouse" itemprop="url" >
                        Blouse
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Short sleeved blouse with feminine draped sleeve detail.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$27.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=2&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="2">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="3"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/9/79-home_default.jpg" alt="Printed Dress" title="Printed Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="3"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_3" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '3', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" data-id-product="3" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url" >
                        Printed Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    100% cotton double printed dress. Black and white striped top and orange high waisted skater skirt bottom.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$26.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=3&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="3">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="5"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/2/102-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="5"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_5" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '5', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" data-id-product="5" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$28.98						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$30.51
							</span>
                    <span class="price-percent-reduction">-5%</span>


                </div>
                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=5&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="5">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 last_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="6"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/4/84-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="6"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_6" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '6', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" data-id-product="6" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Sleeveless knee-length chiffon dress. V-neckline with elastic under the bust lining.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$30.50						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=6&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="6">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>
</div>

</div>
</div>
<div class="item ">
    <div class="product_list grid">
        <div class="row">
            <div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">

                <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
                    <div class="left-block">
                        <div class="product-image-container image">
                            <div class="leo-more-info" data-idproduct="7"></div>
                            <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                                <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/7/87-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                                <span class="product-additional" data-idproduct="7"></span>
                            </a>
                        </div>


                        <div class="functional-buttons-detail">
                            <div class="action-button  clearfix">
                                <div class="wishlist">


                                    <a class="btn-tooltip addToWishlist wishlistProd_7" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '7', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                                        <i class="fa fa-heart"></i>
                                    </a>
                                </div>

                                <div class="compare">
                                    <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" data-id-product="7" title="Add to compare" >
                                        <i class="fa fa-refresh"></i>
                                    </a>
                                </div>
                                <div class="button-quick-view">
                                    <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Quick view" >
                                        <i class="fa fa-search-plus"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="right-block">
                        <div class="product-meta">
                            <h5 itemprop="name" class="name">
                                <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                                    Printed Chiffon...
                                </a>
                            </h5>
                            <p class="product-desc" itemprop="description">
                                Printed chiffon knee length dress with tank straps. Deep v-neckline.
                            </p>


                            <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                                <div class="star_content">
                                    <div class="star"></div>
                                    <div class="star"></div>
                                    <div class="star"></div>
                                    <div class="star"></div>
                                    <div class="star"></div>
                                    <meta itemprop="worstRating" content = "0" />
                                    <meta itemprop="ratingValue" content = "0" />
                                    <meta itemprop="bestRating" content = "5" />
                                </div>
                                <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                            </div>


                            <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                                <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                                <span class="price-percent-reduction">-20%</span>


                            </div>
                            <div class="product-flags">
                                <span class="discount label label-danger">Reduced price!</span>
                            </div>


                            <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                            </div>
                            <div class="functional-buttons clearfix">
                                <div class="cart">
                                    <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=7&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="7">
                                        <span>Add to cart</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- .product-container> -->


            </div>
        </div>

    </div>
</div>
</div>
</div>





</div>


<div class="tab-pane" id="leoproducttab216430965featured">
<div class="carousel slide" id="leoproducttab216430965-featured">

<a class="carousel-control left" href="#leoproducttab216430965-featured"   data-slide="prev">&lsaquo;</a>
<a class="carousel-control right" href="#leoproducttab216430965-featured"  data-slide="next">&rsaquo;</a>

<div class="carousel-inner">
<div class="item active">
<div class="product_list grid">
<div class="row">
<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="1"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Faded Short Sleeve T-shirts" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/4/74-home_default.jpg" alt="Faded Short Sleeve T-shirts" title="Faded Short Sleeve T-shirts" itemprop="image" />
                    <span class="product-additional" data-idproduct="1"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_1" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '1', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" data-id-product="1" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="Faded Short Sleeve T-shirts" itemprop="url" >
                        Faded Short...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Faded short sleeve t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.51						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=1&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="1">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="2"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Blouse" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/6/76-home_default.jpg" alt="Blouse" title="Blouse" itemprop="image" />
                    <span class="product-additional" data-idproduct="2"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_2" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '2', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" data-id-product="2" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="Blouse" itemprop="url" >
                        Blouse
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Short sleeved blouse with feminine draped sleeve detail.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$27.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=2&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="2">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="3"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/7/9/79-home_default.jpg" alt="Printed Dress" title="Printed Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="3"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_3" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '3', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" data-id-product="3" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url" >
                        Printed Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    100% cotton double printed dress. Black and white striped top and orange high waisted skater skirt bottom.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$26.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=3&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="3">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="4"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=4&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/0/80-home_default.jpg" alt="Printed Dress" title="Printed Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="4"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_4" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '4', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=4&amp;controller=product&amp;id_lang=1" data-id-product="4" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=4&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=4&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=4&amp;controller=product&amp;id_lang=1" title="Printed Dress" itemprop="url" >
                        Printed Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed evening dress with straight sleeves with black thin waist belt and ruffled linings.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$50.99						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=4&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="4">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 last_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="5"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/2/102-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="5"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_5" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '5', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" data-id-product="5" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$28.98						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$30.51
							</span>
                    <span class="price-percent-reduction">-5%</span>


                </div>
                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=5&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="5">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>
</div>

</div>
</div>
<div class="item ">
<div class="product_list grid">
<div class="row">
<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="6"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/4/84-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="6"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_6" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '6', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" data-id-product="6" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Sleeveless knee-length chiffon dress. V-neckline with elastic under the bust lining.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$30.50						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=6&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="6">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="7"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/7/87-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="7"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_7" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '7', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" data-id-product="7" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                        Printed Chiffon...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed chiffon knee length dress with tank straps. Deep v-neckline.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                    <span class="price-percent-reduction">-20%</span>


                </div>
                <div class="product-flags">
                    <span class="discount label label-danger">Reduced price!</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=7&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="7">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="8"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=8&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/8/8/88-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="8"></span>
                </a>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_8" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '8', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=8&amp;controller=product&amp;id_lang=1" data-id-product="8" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=8&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=8&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=8&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Faded short sleeve t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$20.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In Stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=8&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="8">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 ">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="10"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=10&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/9/2/92-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="10"></span>
                </a>
										<span class="sale-box">
					<span class="sale-label product-label">Sale!</span>
				</span>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_10" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '10', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=10&amp;controller=product&amp;id_lang=1" data-id-product="10" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=10&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=10&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=10&amp;controller=product&amp;id_lang=1" title="Printed Summer Dress" itemprop="url" >
                        Printed Summer Dress
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Faded short sleeve t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$20.00						</span>
                    <meta itemprop="priceCurrency" content="USD" />


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In Stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=10&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="10">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>

<div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 last_item">

    <div class="product-container product-block" itemscope itemtype="http://schema.org/Product">
        <div class="left-block">
            <div class="product-image-container image">
                <div class="leo-more-info" data-idproduct="11"></div>
                <a class="product_img_link"	href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url">
                    <img class="replace-2x img-responsive" src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/9/4/94-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress" itemprop="image" />
                    <span class="product-additional" data-idproduct="11"></span>
                </a>
										<span class="sale-box">
					<span class="sale-label product-label">Sale!</span>
				</span>
            </div>


            <div class="functional-buttons-detail">
                <div class="action-button  clearfix">
                    <div class="wishlist">


                        <a class="btn-tooltip addToWishlist wishlistProd_11" href="#" onclick="WishlistCart('wishlist_block_list', 'add', '11', false, 1); return false;" data-toggle="tooltip" title="Add to Wishlist">
                            <i class="fa fa-heart"></i>
                        </a>
                    </div>

                    <div class="compare">
                        <a class="add_to_compare compare btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" data-id-product="11" title="Add to compare" >
                            <i class="fa fa-refresh"></i>
                        </a>
                    </div>
                    <div class="button-quick-view">
                        <a class="quick-view btn btn-tooltip" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" rel="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Quick view" >
                            <i class="fa fa-search-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="right-block">
            <div class="product-meta">
                <h5 itemprop="name" class="name">
                    <a class="product-name" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=11&amp;controller=product&amp;id_lang=1" title="Printed Chiffon Dress" itemprop="url" >
                        Printed Chiffon...
                    </a>
                </h5>
                <p class="product-desc" itemprop="description">
                    Printed chiffon knee length dress with tank straps. Deep v-neckline.
                </p>


                <div class="comments_note product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                    <div class="star_content">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <meta itemprop="worstRating" content = "0" />
                        <meta itemprop="ratingValue" content = "0" />
                        <meta itemprop="bestRating" content = "5" />
                    </div>
                    <span class="nb-comments"><span itemprop="reviewCount">0</span> Review(s)</span>
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
											<span itemprop="price" class="price product-price">
							$16.40						</span>
                    <meta itemprop="priceCurrency" content="USD" />

							<span class="old-price product-price">
								$20.50
							</span>
                    <span class="price-percent-reduction">-20%</span>


                </div>
                <div class="product-flags">
                </div>


                <div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
													<span class="available-now">
								<link itemprop="availability" href="http://schema.org/InStock" />In stock							</span>
                </div>
                <div class="functional-buttons clearfix">
                    <div class="cart">
                        <a class="button ajax_add_to_cart_button btn btn-outline" href="http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=cart&amp;add=1&amp;id_product=11&amp;token=b780f4fb17b185b4b307d81526c2320c" rel="nofollow" title="Add to cart" data-id-product="11">
                            <span>Add to cart</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .product-container> -->


</div>
</div>

</div>
</div>
</div>
</div>





</div>


</div></div>


</div>
</div>
<!-- /MODULE Block specials -->
<script>
    $(document).ready(function() {
        $('#leoproducttab216430965 .carousel').each(function(){
            $(this).carousel({
                pause: 'hover',
                interval: 8000
            });
        });

        $("#leoproducttab216430965 .nav-pills li", this).first().addClass("active");
        $("#leoproducttab216430965 .tab-content .tab-pane", this).first().addClass("active");

    });
</script>
</div>
</div>

</div>
</div>
<div class="row">


<!-- Center -->
<section id="center_column" class="col-md-9">
<div id="breadcrumb" class="clearfix">

    <!-- Breadcrumb -->
    <div class="breadcrumb clearfix">
        <a class="home" href="" title="Return to Home"><i class="fa fa-home"></i></a>
        <?php foreach($nav as $k => $obj):?>

            <?php if(count($nav) == $k+1): ?>
                <span class="navigation-pipe">></span><?=ucfirst($obj['name'])?></span>
            <?php else: ?>
                <span  class="navigation-pipe">></span><span itemscope itemtype="">
                <a itemprop="url" href="<?=base_url().$obj['url']."/".$this->encrypt->myEncode('m-'.$obj['id'])?>"   title="<?=ucfirst($obj['name'])?>">
                    <span itemprop="title"><?=ucfirst($obj['name'])?></span>
                </a>
            </span>
            <?php endif; ?>

        <?php endforeach;?>


    </div>
    <!-- /Breadcrumb -->
</div>




<div class="primary_block row" itemscope itemtype="http://schema.org/Product">
<div class="container">
    <div class="top-hr"></div>
</div>
<!-- left infos-->
<div class="pb-left-column col-xs-12 col-sm-12 col-md-5">
    <!-- product img-->
    <div id="image-block" class="clearfix">
        <div class="p-label">
            <span class="discount"></span>
        </div>
        <span id="view_full_size">
                        <img id="bigpic" itemprop="image" src="<?=UPLOAD.$item->image?>"
                             title="<?=$item->title?>" alt="<?=$item->title?>"/>
                                <span
                                    class="span_link no-print status-enable btn btn-outline"></span>
                                            </span>
    </div>
    <!-- end image-block -->
    <!-- thumbnails -->
    <div id="views_block" class="clearfix ">
											<span class="view_scroll_spacer">
							<a id="view_scroll_left" class="" title="Other views" href="javascript:{}">
                                Previous
                            </a>
						</span>

        <div id="thumbs_list">
            <ul id="thumbs_list_frame">
                <li id="thumbnail_82">
                    <a href="<?=UPLOAD.$item->image?>" data-fancybox-group="other-views" class="fancybox"
                       title="<?=$item->title?>">
                        <img class="img-responsive" id="thumb_82" src="<?=UPLOAD_THUMBS.$item->image?>"
                             alt="<?=$item->title?>" title="<?=$item->title?>" itemprop="image"/>
                    </a>
                </li>
                <?php foreach($item->sub_image as $k => $image): ?>
                    <li id="thumbnail_<?=$k?>">
                        <a href="<?=UPLOAD.$image->image?>" data-fancybox-group="other-views" class="fancybox"
                           title="<?=$item->title?>">
                            <img class="img-responsive" id="thumb_83" src="<?=UPLOAD_THUMBS.$image->image?>"
                                 alt="<?=$item->title?>" title="<?=$item->title?>" itemprop="image"/>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <!-- end thumbs_list -->
        <a id="view_scroll_right" title="Other views" href="javascript:{}">
            Next
        </a>
    </div>
    <!-- end views-block -->
    <!-- end thumbnails -->
    <p class="resetimg clear no-print">
					<span id="wrapResetImages" style="display: none;">
						<a href="" name="resetImages">
                            <i class="fa fa-repeat"></i>
                            Display all pictures
                        </a>
					</span>
    </p>
</div>
<!-- end pb-left-column -->
<!-- end left infos-->
<!-- center infos -->
<div class="pb-center-column col-lg-6 col-sm-6 col-md-4">

    <h1 itemprop="name"><?=$item->title?></h1>
    <p class="socialsharing_product list-inline no-print">
        <button type="button" class="btn btn-twitter" onclick="socialsharing_twitter_click('');">
            <i class="fa fa-twitter"></i> Tweet
            <!-- <img src="http://demo4leotheme.com/prestashop/leo_flowers/modules/socialsharing/img/twitter.gif" alt="Tweet" /> -->
        </button>
        <button type="button" class="btn btn-facebook" onclick="socialsharing_facebook_click();">
            <i class="fa fa-facebook"></i> Share
            <!-- <img src="http://demo4leotheme.com/prestashop/leo_flowers/modules/socialsharing/img/facebook.gif" alt="Facebook Like" /> -->
        </button>
        <button type="button" class="btn btn-google-plus" onclick="socialsharing_google_click();">
            <i class="fa fa-google-plus"></i> Google+
            <!-- <img src="http://demo4leotheme.com/prestashop/leo_flowers/modules/socialsharing/img/google.gif" alt="Google Plus" /> -->
        </button>
        <button type="button" class="btn btn-pinterest" onclick="socialsharing_pinterest_click();">
            <i class="fa fa-pinterest"></i> Pinterest
            <!-- <img src="http://demo4leotheme.com/prestashop/leo_flowers/modules/socialsharing/img/pinterest.gif" alt="Pinterest" /> -->
        </button>
    </p>

    <!--  /Module ProductComments -->
    <p id="product_reference">
        <label>Reference: </label>
        <span class="editable" itemprop="sku"></span>
    </p>
    <p id="product_condition">
        New
    </p>
    <div id="short_description_block">
        <div id="short_description_content" class="rte align_justify" itemprop="description"><p>
                <?=$item->long?>
            </p></div>

        <!-- 						<p class="buttons_bottom_block">
                <a href="javascript:{}" class="button btn status-enable">
                    More details
                </a>
            </p>
         -->
        <!---->
    </div> <!-- end short_description_block -->
    <!-- number of item in stock -->
    <p id="pQuantityAvailable">
        <span id="quantityAvailable">3600</span>
        <span  style="display: none;" id="quantityAvailableTxt">Item</span>
        <span  id="quantityAvailableTxtMultiple">Items</span>
    </p>
    <!-- availability or doesntExist -->
    <p id="availability_statut">

        <span id="availability_value">In stock</span>
    </p>

    <p class="warning_inline" id="last_quantities" style="display: none" >Warning: Last items in stock!</p>
    <p id="availability_date" style="display: none;">
        <span id="availability_date_label">Availability date:</span>
        <span id="availability_date_value">0000-00-00</span>
    </p>
    <!-- Out of stock hook -->
    <div id="oosHook" style="display: none;">

    </div>

    <!-- usefull links-->
    <ul id="usefull_link_block" class="clearfix no-print">
        <li class="sendtofriend">
            <a id="send_friend_button" href="#send_friend_form">
                Send to a friend
            </a>
            <div style="display: none;">
                <div id="send_friend_form">
                    <h2  class="page-subheading">
                        Send to a friend
                    </h2>
                    <div class="row">
                        <div class="product clearfix col-xs-12 col-sm-6">
                            <img src="http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/2/102-home_default.jpg" alt="<?=$item->title?>" />
                            <div class="product_desc">
                                <p class="product_name">
                                    <strong><?=$item->title?></strong>
                                </p>
                                <p><?=$item->long?></p>
                            </div>
                        </div><!-- .product -->
                        <div class="send_friend_form_content col-xs-12 col-sm-6" id="send_friend_form_content">
                            <div id="send_friend_form_error"></div>
                            <div id="send_friend_form_success"></div>
                            <div class="form_container">
                                <p class="intro_form">
                                    Recipient :
                                </p>
                                <p class="text">
                                    <label for="friend_name">
                                        Name of your friend <sup class="required">*</sup> :
                                    </label>
                                    <input id="friend_name" name="friend_name" type="text" value="" class="form-control"/>
                                </p>
                                <p class="text">
                                    <label for="friend_email">
                                        E-mail address of your friend <sup class="required">*</sup> :
                                    </label>
                                    <input id="friend_email" name="friend_email" type="text" value="" class="form-control"/>
                                </p>
                                <p class="txt_required">
                                    <sup class="required">*</sup> Required fields
                                </p>
                            </div>
                            <p class="submit">
                                <button id="sendEmail" class="btn button button-small btn-sm" name="sendEmail" type="submit">
                                    <span>Send</span>
                                </button>&nbsp;
                                or&nbsp;
                                <a class="closefb" href="#">
                                    Cancel
                                </a>
                            </p>
                        </div> <!-- .send_friend_form_content -->
                    </div>
                </div>
            </div>
        </li>





        <li class="print">
            <a href="javascript:print();">
                Print
            </a>
        </li>
    </ul>
</div>
<!-- end center infos-->
<!-- pb-right-column-->
 <!-- end pb-right-column-->
</div> <!-- end primary_block -->


<section class="page-product-box blockproductscategory products_block block nopadding">
<h4 class="page-subheading productscategory_h3">Related Products</h4>
<div id="productscategory_list" class="clearfix product_list grid">
<div class="block_content">
<div class=" carousel slide" id="blockproductscategory">


<div class="carousel-inner">
<div class="item active">
    <div class="row clearfix">
        <?php
        $url= str_replace( url_title($item->title) ,"",new_current_url() );
        ?>
        <?php foreach($related as $obj ): ?>

            <div class="col-sm-3 col-xs-12 product_block ajax_block_product">
                <div class="product-container product-block" itemscope itemtype="">
                    <div class="left-block">
                        <div class="product-image-container image">
                            <div class="leo-more-info" data-idproduct="<?=$obj->id?>"></div>
                            <a class="product_img_link" href="<?=$url.url_title($obj->title)."/".$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                                <img class="replace-2x img-responsive" src="<?=UPLOAD.$obj->image?>" alt="<?=$obj->title?>" title="<?=$obj->title?>"
                                     itemprop="image"/>
                                <span class="product-additional" data-idproduct="<?=$obj->id?>"></span>
                            </a>
                        </div>
                    </div>
                    <div class="right-block">
                        <div class="product-meta">
                            <h5 itemprop="name" class="name">
                                <a class="product-name" href="<?=$url.url_title($obj->title).$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                                    <?=$obj->title?>
                                </a>
                            </h5>

                            <p class="product-desc" itemprop="description">
                                <?=$obj->short?>
                            </p>


                            <div class="functional-buttons clearfix">
                                <div class="cart">
                                    <a class="button ajax_add_to_cart_button btn btn-outline" href="" rel="nofollow"
                                       title="Add to cart" data-id-product="<?=$obj->id?>">
                                        <span>View More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- .product-container> -->
            </div>
        <?php endforeach; ?>
    </div>
</div>

</div>
</div>
</div>
</div>
</section>







</section>
<!-- Right -->
<section id="right_column" class="column sidebar col-md-3">
    <!-- MODULE Block cart -->
    <div class="shopping_cart">
        <div class="media heading">
            <div class="title-cart pull-right">
                <span class="icon-cart"></span></div>
            <div class="cart-inner media-body">
                <h4 class="title_block"><a href="" title="View my shopping cart" rel="nofollow">Quick Contact</a></h4>

            </div>
        </div>



        <div class="cart_block block exclusive">
            <div class="block_content">
                <p style="font-size:17px;">248, Sea Street, <br/>
                    Colombo- 11, Sri Lanka.<br/>
                    Tel: +94 112 447 421<br/>
                    Mobile: +94 777 444 333<br/>
                    Email: Info@homeplus.com<br/>
                </p>
                <span><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.5607083593627!2d79.85484210000003!3d6.942985500000012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae258e0356f9015%3A0x5cf97a5e151c4ff1!2sSea+St%2C+Colombo+01100!5e0!3m2!1sen!2slk!4v1425215902797" width="280" height="250" frameborder="0" style="border:0"></iframe></span>
            </div>
        </div><!-- .cart_block -->
    </div>

    <div id="categories_block_left" class="block block-primary">
        <h4 class="title_block">
            Categories
        </h4>
        <div class="block_content">
            <ul class="list-block list-group bullet tree dhtml">

                <li >
                    <a href="" title="Women">
                        Baffle Grease Fliters
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>


                <li >
                    <a href="" title="Women">
                        Restaurant Ranges
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>


                <li >
                    <a href="" title="Women">
                        Refrigeration
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>


                <li >
                    <a href="" title="Women">
                        Stainless Tables
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>
                <li >
                    <a href="" title="Women">
                        Char Broilers
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>
                <li >
                    <a href="" title="Women">
                        One Piece Ladles
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>
                <li >
                    <a href="" title="Women">
                        Refrigeration
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>


                <li >
                    <a href="" title="Women">
                        Stainless Tables
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>
                <li >
                    <a href="" title="Women">
                        Char Broilers
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>
                <li >
                    <a href="" title="Women">
                        One Piece Ladles
                        <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                    </a>

                </li>

            </ul>
        </div>
    </div>


</section>


</div>
</div>
</section>
<!-- Footer -->
<footer id="footer" class="footer-container">

    <section id="footernav" class="footer-nav">
        <div class="container">
            <div class="inner">
                <div id="powered">
                    Copyright 2015 Home Plus. All Rights Reserved.
                    | Powered by <span>IT MARTX</span>
                </div><!-- #poweredby -->

            </div>
        </div>
    </section>
</footer><!-- .footer-container -->
</section><!-- #page -->


</body></html>