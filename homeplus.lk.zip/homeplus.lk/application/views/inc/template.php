<?php
/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 4/21/15
 * Time: 4:42 PM
 */

define("IMAGE",base_url()."images/");
define("CSS",base_url()."css/");
define("JS",base_url()."js/");
define('UPLOAD',base_url() . 'uploads/');
define('UPLOAD_THUMBS',base_url() . 'uploads/thumbs/');

$this->load->view('inc/head');
$this->load->view('inc/header');
$this->load->view('inc/nav');
$this->load->view("$view");
$this->load->view('inc/footer');
$this->load->view('inc/foot');