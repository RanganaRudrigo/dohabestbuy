<!-- Footer -->
<footer id="footer" class="footer-container">

    <section id="footernav" class="footer-nav">
        <div class="container">
            <div class="inner">
                <div id="powered">
                    Copyright 2015 Home Plus. All Rights Reserved.
                    | Powered by <span>IT MARTX</span>
                </div>
                <!-- #poweredby -->

            </div>
        </div>
    </section>
</footer>
<!-- .footer-container -->
</section>
<!-- #page -->


</body>
</html>