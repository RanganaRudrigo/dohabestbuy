<body id="index" class="index hide-left-column lang_en fullwidth  double-menu">
<h1 class="hidden">leo_flowers</h1>
<section id="page" data-column="col-xs-12 col-sm-6 col-md-3" data-type="grid">
    <!-- Header -->
    <header id="header">
        <section class="header-container">
            <div id="topbar">
                <div class="banner">
                    <div class="container">
                        <div class="row">

                        </div>
                    </div>
                </div>
                <div class="nav">
                    <div class="container">
                        <div class="inner">
                            <nav>
                                <script type="text/javascript">
                                    /* Blockusreinfo */

                                    $(document).ready(function () {
                                        if ($(window).width() < 991) {
                                            $(".header_user_info").addClass('btn-group');
                                            $(".header_user_info .links").addClass('quick-setting dropdown-menu');
                                        }
                                        else {
                                            $(".header_user_info").removeClass('btn-group');
                                            $(".header_user_info .links").removeClass('quick-setting dropdown-menu');
                                        }
                                        $(window).resize(function () {
                                            if ($(window).width() < 991) {
                                                $(".header_user_info").addClass('btn-group');
                                                $(".header_user_info .links").addClass('quick-setting dropdown-menu');
                                            }
                                            else {
                                                $(".header_user_info").removeClass('btn-group');
                                                $(".header_user_info .links").removeClass('quick-setting dropdown-menu');
                                            }
                                        });
                                    });
                                </script>
                                <!-- Block user information module NAV  -->
                                <div class="header_user_info pull-right">
                                    <div data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-cog"></i><span>Top links </span>
                                    </div>
                                    <ul class="links">
                                        <li><a class="login" href="" rel="nofollow" title="Login to your customer account">
                                                Home
                                            </a></li>

                                        <li>
                                            <a href="" title="My account">Conatct Us</a>
                                        </li>


                                    </ul>

                                </div>
                                <div class="btn-group">
                                    <div data-toggle="dropdown" class="dropdown-toggle"><span class="hidden-xs">Tel : +94 112 447 421 | Email : info@homeplus.com </span>


                                    </div>

                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div id="header-main">
                <div class="container">
                    <div class="inner">
                        <div class="row">
                            <div id="header_logo" class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                <a href="<?=base_url()?>" title="leo_flowers">
                                    <img class="logo img-responsive" src="<?=IMAGE?>logo.png" alt="leo_flowers" width="389"
                                         height="79"/>
                                </a>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-9 col-lg-9">
                                <!-- MODULE Block cart -->
                                <div class="blockcart_top clearfix">
                                    <div class="shopping_cart">
                                        <div class="media heading">

                                            <div class="cart-inner media-body">
                                                <h4 class="title_block"><a href="" title="View my shopping cart"
                                                                           rel="nofollow">Hotline : +94 777 444 333</a></h4>
                                                <h4 class="title_block"><a href="" title="View my shopping cart"
                                                                           rel="nofollow">Email : Info@homeplus.com</a></h4>

                                            </div>
                                        </div>


                                    </div>
                                </div>


                                <!-- /MODULE Block cart -->
                                <div class=""
                                    >

                                    <div class="widget col-lg-8 col-md-8 col-sm-8 col-xs-8 col-sp-12 hidden-sp hidden-xs hidden-sm text-center"
                                        >

                                        <div class="widget-html block">
                                            <div class="block_content">
                                                <p><a href="#"><img src="<?=IMAGE?>adv-top.png" alt=""/></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </header>
