

</div>
<script>
    $("#content .button").wrap('<div class="btn"></div>');
</script>
<span class="grid_default_width" style="display: none; visibility: hidden;" ></span>
<span class="home_products_default_width" style="display:none; visibility:hidden"></span>
<span class="module_default_width" style="display:none; visibility:hidden"></span>
</body>
</html>