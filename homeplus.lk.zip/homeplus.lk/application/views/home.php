<div id="slideshow" class="clearfix">
    <div class="container">
        <div class="bannercontainer banner-fullwidth" style="padding: 0;margin: 0px;background-color:#d9d9d9">
            <div id="sliderlayer54624247" class="rev_slider fullwidthbanner" style="width:100%;height:550px; ">
                <ul>


                    <li data-masterspeed="300" data-transition="random" data-slotamount="7"
                        data-thumb="images/bg-slide-2.png">
                        <img src="images/bg-slide-2.png" alt=""/>

                        <div class="caption title_slier sfb easeInOutQuart                        "
                             data-x="662"
                             data-y="137"
                             data-speed="300"
                             data-start="1600"
                             data-easing="easeOutExpo"
                             style="font-size:43px;background-color:transparent;color:#4da9c7;z-index: 66;">


                            Equipment and supplies to accomodate small and large, hot and cold buffets

                        </div>
                        <div class="caption slider_dec sfb easeInOutQuart                        stb"
                             data-x="662"
                             data-y="290"
                             data-speed="300"
                             data-start="2000"
                             data-easing="easeOutExpo" onclick="window.open('#','_self');"
                             style="font-size:14px;color:#747676;z-index: 67;">


                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis fringilla nisi
                            euismod Morbi sed adipiscing eleifend, dolor risus congue mi aliquet dolor tellus et ante.

                        </div>
                        <div class="caption btn-links sfb easeInOutQuart                        stl"
                             data-x="662"
                             data-y="377"
                             data-speed="300"
                             data-start="2400"
                             data-easing="easeOutExpo" onclick="window.open('#','_self');"
                             style="font-size:14px;background-color:#747676;color:#fff;z-index: 68;">


                            View More

                        </div>
                        <div class="caption sfb easeInOutQuart                        "
                             data-x="60"
                             data-y="50"
                             data-speed="300"
                             data-start="2000"
                             data-easing="easeOutExpo">

                            <img src="images/img-4.png" alt=""/>

                        </div>
                    </li>

                    <li data-masterspeed="300" data-transition="random" data-slotamount="7"
                        data-thumb="images/bg-slide-1.png">
                        <img src="images/bg-slide-1.png" alt=""/>

                        <div class="caption title_slier sfb easeInOutQuart                        "
                             data-x="662"
                             data-y="137"
                             data-speed="300"
                             data-start="1600"
                             data-easing="easeOutExpo"
                             style="font-size:43px;background-color:transparent;color:#4da9c7;z-index: 66;">

                            For all your catering and buffet needs, you need look no further.


                        </div>
                        <div class="caption slider_dec sfb easeInOutQuart                        stb"
                             data-x="662"
                             data-y="240"
                             data-speed="300"
                             data-start="2000"
                             data-easing="easeOutExpo" onclick="window.open('#','_self');"
                             style="font-size:14px;color:#747676;z-index: 67;">


                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis fringilla nisi
                            euismod Morbi sed adipiscing eleifend, dolor risus congue mi aliquet dolor tellus et ante.

                        </div>
                        <div class="caption btn-links sfb easeInOutQuart                        stl"
                             data-x="662"
                             data-y="307"
                             data-speed="300"
                             data-start="2400"
                             data-easing="easeOutExpo" onclick="window.open('#','_self');"
                             style="font-size:14px;background-color:#747676;color:#fff;z-index: 68;">


                            View More

                        </div>
                        <div class="caption sfb easeInOutQuart                        "
                             data-x="60"
                             data-y="50"
                             data-speed="300"
                             data-start="2000"
                             data-easing="easeOutExpo">

                            <img src="images/img-5.png" alt=""/>

                        </div>
                    </li>
                </ul>

                <div class="tp-bannertimer tp-top"></div>
            </div>
        </div>

        <script type="text/javascript">
            var tpj = jQuery;
            if (tpj.fn.cssOriginal != undefined)
                tpj.fn.css = tpj.fn.cssOriginal;
            tpj("#sliderlayer54624247").revolution(
                {
                    delay: 9000,
                    startheight: 550,
                    startwidth: 1170,
                    hideThumbs: 200,
                    thumbWidth: 100,
                    thumbHeight: 50,
                    thumbAmount: 5,
                    navigationType: "bullet",
                    navigationArrows: "none",
                    navigationStyle: "round",
                    navOffsetHorizontal: 0,
                    navOffsetVertical: 20,
                    touchenabled: "on",
                    onHoverStop: "on",
                    shuffle: "on",
                    stopAtSlide: -1,
                    stopAfterLoops: -1,
                    hideCaptionAtLimit: 0,
                    hideAllCaptionAtLilmit: 0,
                    hideSliderAtLimit: 0,
                    fullWidth: "on",
                    shadow: 0,
                    startWithSlide: 0
                });
            $(document).ready(function () {
                $('.caption', $('#sliderlayer54624247')).click(function () {
                    if ($(this).data('link') != undefined && $(this).data('link') != '') location.href = $(this).data('link');
                });
            });
        </script>
    </div>
</div>

<!-- Content -->
<section id="columns" class="columns-container">
<div class="container">
<div class="row">
<div id="top_column" class="center_column col-xs-12 col-sm-12 col-md-12">

<div class="row">

<div class="widget col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12">

<!-- MODULE Block specials -->
<div id="leoproducttab538126914" class="products_block exclusive block nopadding">
<div class="block_content">
<br/>

<div id="product_tab_content">
<div class="product_tab_content tab-content">

<div class="tab-pane" id="leoproducttab538126914special">
<div class="carousel slide" id="leoproducttab538126914-special">

<div class="carousel-inner">
<div class="item active">
<div class="product_list grid">
<div class="row">
<?php foreach($best_seller as $k => $obj ): ?>
    <?php if($k == 5 ) break ; ?>
    <div class=" ajax_block_product product_block col-md-2-4 col-lg-2-4 col-xs-6 col-sp-12 first_item">
        <div class="product-container product-block" itemscope itemtype="">
            <div class="left-block">
                <div class="product-image-container image">
                    <div class="leo-more-info" data-idproduct="<?=$obj->id?>"></div>
                    <a class="product_img_link" href="<?=new_current_url()."/Best_Seller/".url_title($obj->title)."/".$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                        <img class="replace-2x img-responsive" src="<?=UPLOAD.$obj->image?>"
                             alt="Buffet Tool Set" title="<?=$obj->title?>" itemprop="image"/>
                        <span class="product-additional" data-idproduct="<?=$obj->id?>"></span>
                    </a>
                </div>
            </div>
            <div class="right-block">
                <div class="product-meta">
                    <h5 itemprop="name" class="name">
                        <a class="product-name" href="<?=new_current_url()."/Best_Seller/".url_title($obj->title)."/".$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                            <?=$obj->title?>
                        </a>
                    </h5>
                    <p class="product-desc" itemprop="description">
                        <?=$obj->short?>
                    </p>
                    <div class="functional-buttons clearfix">
                        <div class="cart">
                            <a class="button ajax_add_to_cart_button btn btn-outline" href="" rel="nofollow"
                               title="Add to cart" data-id-product="<?=$obj->id?>">
                                <span>View More</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .product-container> -->
    </div>
<?php endforeach; ?>
</div>

</div>
</div>
</div>
</div>


</div>


</div>
</div>


</div>
</div>
<!-- /MODULE Block specials -->
<script>
    $(document).ready(function () {
        $('#leoproducttab538126914 .carousel').each(function () {
            $(this).carousel({
                pause: 'hover',
                interval: 8000
            });
        });

        $("#leoproducttab538126914 .nav-pills li", this).first().addClass("active");
        $("#leoproducttab538126914 .tab-content .tab-pane", this).first().addClass("active");

    });
</script>
</div>
</div>

</div>
</div>
<div class="row">


<!-- Center -->
<section id="center_column" class="col-md-9">


<div id="contentbottom" class="no-border clearfix block">

<div class="">

    <div class="widget col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12 adv_home">

        <div class="widget-html block">
            <div class="block_content">
                <div class="customhtml">
                    <h4 class="title_block_gt">Welcome to Home Plus</h4>

                    <div class="block_content_ct">
                        <p>Welcome to Home Plus, your number one source for all things Kitchen Utensils & Kitchen Machines in Srilanka. We’re dedicated to giving you the very best of Kitchen Utensils & Kitchen Machines, with a focus on Dependability, Budget & Quality.</p>

                        <div class="row"><a class="col-md-6 col-xs-6 col-sp-12 " href="#"> <img
                                    src="images/adv-home-1.jpg" alt=""/> </a> <a class="col-md-6 col-xs-6 col-sp-12 "
                                                                                 href="#"><img src="images/adv-home-2.jpg"
                                                                                               alt=""/></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">

<div class="widget col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12">

<div class="products_block exclusive leomanagerwidgets  block nopadding">
<h4 class="page-subheading">
    Featured products
</h4>

<div class="block_content">
<div class="carousel slide" id="leoproductcarousel381687522">

<div class="carousel-inner">
<div class="item active">
<div class="product_list grid">
<div class="row">
<?php foreach($feature_product as $k => $obj ): ?>
    <div class=" ajax_block_product product_block col-md-3 col-xs-6 col-sp-12 first_item">
        <div class="product-container product-block" itemscope itemtype="">
            <div class="left-block">
                <div class="product-image-container image">
                    <div class="leo-more-info" data-idproduct="<?=$obj->id?>"></div>
                    <a class="product_img_link" href="<?=new_current_url()."/Featured_products/".url_title($obj->title)."/".$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                        <img class="replace-2x img-responsive" src="<?=UPLOAD.$obj->image?>"
                             alt="Buffet Tool Set" title="<?=$obj->title?>" itemprop="image"/>
                        <span class="product-additional" data-idproduct="<?=$obj->id?>"></span>
                    </a>
                </div>
            </div>
            <div class="right-block">
                <div class="product-meta">
                    <h5 itemprop="name" class="name">
                        <a class="product-name" href="<?=new_current_url()."/Featured_products/".url_title($obj->title)."/".$this->encrypt->myEncode('P-'.$obj->id)?>" title="<?=$obj->title?>" itemprop="url">
                            <?=$obj->title?>
                        </a>
                    </h5>
                    <p class="product-desc" itemprop="description">
                        <?=$obj->short?>
                    </p>
                    <div class="functional-buttons clearfix">
                        <div class="cart">
                            <a class="button ajax_add_to_cart_button btn btn-outline" href="" rel="nofollow"
                               title="Add to cart" data-id-product="<?=$obj->id?>">
                                <span>View More</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .product-container> -->
    </div>
<?php endforeach; ?>
</div>


</div>
</div>
</div>
</div>


</div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#leoproductcarousel381687522').each(function () {
            $(this).carousel({
                pause: 'hover',
                interval: 8000
            });
        });
    });
</script>
</div>
</div>

</div>
</section>
<!-- Right -->
<section id="right_column" class="column sidebar col-md-3">
    <!-- MODULE Block cart -->
    <div class="shopping_cart">
        <div class="media heading">
            <div class="title-cart pull-right">
                <span class="icon-cart"></span></div>
            <div class="cart-inner media-body">
                <h4 class="title_block"><a href="" title="View my shopping cart" rel="nofollow">Quick Contact</a></h4>

            </div>
        </div>


        <div class="cart_block block exclusive">
            <div class="block_content">
                <p style="font-size:17px;">248, Sea Street, <br/>
                    Colombo- 11, Sri Lanka.<br/>
                    Tel: +94 112 447 421<br/>
                    Mobile: +94 777 444 333<br/>
                    Email: Info@homeplus.com<br/>
                </p>
                <span><iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.5607083593627!2d79.85484210000003!3d6.942985500000012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae258e0356f9015%3A0x5cf97a5e151c4ff1!2sSea+St%2C+Colombo+01100!5e0!3m2!1sen!2slk!4v1425215902797"
                        width="280" height="250" frameborder="0" style="border:0"></iframe></span>
            </div>
        </div>
        <!-- .cart_block -->
    </div>

    <div id="categories_block_left" class="block block-primary">
        <h4 class="title_block">
            Categories
        </h4>

        <div class="block_content">
            <ul class="list-block list-group bullet tree dhtml">
                <?php foreach($menus as $menu ): ?>
                    <li>
                        <a href="<?=base_url().url_title($menu->title)."/".$this->encrypt->myEncode('m-'.$menu->id) ?>" title="<?=$menu->title?>">
                           <?=$menu->title?>
                            <span id="leo-cat-3" style="display:none" class="leo-qty badge pull-right"></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>


</section>


</div>
</div>
</section>
