<!DOCTYPE HTML>

<html lang="en-us" class="default">

<head>
<meta charset="utf-8"/>
<title>Home Plus</title>

<meta name="viewport" content="width=device-width, minimum-scale=0.25, maximum-scale=1.6, initial-scale=1.0"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>

<link rel="shortcut icon" type="image/x-icon" href=""/>

<link rel="stylesheet" href="<?= CSS ?>global.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>uniform.default.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>jquery.fancybox.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>product_list.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockcart.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockcategories.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockcurrencies.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blocklanguages.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockcontact.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blocknewsletter.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>jquery.autocomplete.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blocksearch.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockspecials.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockuserinfo.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>homeslider.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>hooks.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>productcomments.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>styles.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>paneltool.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>colorpicker.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>megamenu.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>owl.carousel.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>owl.theme.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>typo.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blockwishlist.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>blogcarousel.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>leoblog.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?= CSS ?>leocustomajax.css" type="text/css" media="all"/>

<script type="text/javascript">
    var CUSTOMIZE_TEXTFIELD = 1;
    var FancyboxI18nClose = 'Close';
    var FancyboxI18nNext = 'Next';
    var FancyboxI18nPrev = 'Previous';
    var PS_CATALOG_MODE = false;
    var added_to_wishlist = 'Added to your wishlist.';
    var ajax_allowed = true;
    var ajaxsearch = true;
    var allowBuyWhenOutOfStock = false;
    var attribute_anchor_separator = '-';
    var attributesCombinations = [
        {"id_attribute": "1", "id_attribute_group": "1", "attribute": "s", "group": "size"},
        {"id_attribute": "16", "id_attribute_group": "3", "attribute": "yellow", "group": "color"},
        {"id_attribute": "14", "id_attribute_group": "3", "attribute": "blue", "group": "color"},
        {"id_attribute": "13", "id_attribute_group": "3", "attribute": "orange", "group": "color"},
        {"id_attribute": "11", "id_attribute_group": "3", "attribute": "black", "group": "color"},
        {"id_attribute": "2", "id_attribute_group": "1", "attribute": "m", "group": "size"},
        {"id_attribute": "3", "id_attribute_group": "1", "attribute": "l", "group": "size"}
    ];
    var availableLaterValue = '';
    var availableNowValue = 'In stock';
    var baseDir = 'http://demo4leotheme.com/prestashop/leo_flowers/';
    var baseUri = 'http://demo4leotheme.com/prestashop/leo_flowers/index.php';
    var blocksearch_type = 'top';
    var combinations = {"21": {"attributes_values": {"1": "S", "3": "Orange"}, "attributes": [1, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','13'"}, "20": {"attributes_values": {"1": "S", "3": "Blue"}, "attributes": [1, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','14'"}, "19": {"attributes_values": {"1": "S", "3": "Yellow"}, "attributes": [1, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','16'"}, "22": {"attributes_values": {"1": "S", "3": "Black"}, "attributes": [1, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','11'"}, "26": {"attributes_values": {"1": "M", "3": "Black"}, "attributes": [2, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','11'"}, "25": {"attributes_values": {"1": "M", "3": "Orange"}, "attributes": [2, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','13'"}, "24": {"attributes_values": {"1": "M", "3": "Blue"}, "attributes": [2, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','14'"}, "23": {"attributes_values": {"1": "M", "3": "Yellow"}, "attributes": [2, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','16'"}, "27": {"attributes_values": {"1": "L", "3": "Yellow"}, "attributes": [3, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','16'"}, "30": {"attributes_values": {"1": "L", "3": "Black"}, "attributes": [3, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','11'"}, "29": {"attributes_values": {"1": "L", "3": "Orange"}, "attributes": [3, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','13'"}, "28": {"attributes_values": {"1": "L", "3": "Blue"}, "attributes": [3, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','14'"}};
    var combinationsFromController = {"21": {"attributes_values": {"1": "S", "3": "Orange"}, "attributes": [1, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','13'"}, "20": {"attributes_values": {"1": "S", "3": "Blue"}, "attributes": [1, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','14'"}, "19": {"attributes_values": {"1": "S", "3": "Yellow"}, "attributes": [1, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','16'"}, "22": {"attributes_values": {"1": "S", "3": "Black"}, "attributes": [1, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'1','11'"}, "26": {"attributes_values": {"1": "M", "3": "Black"}, "attributes": [2, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','11'"}, "25": {"attributes_values": {"1": "M", "3": "Orange"}, "attributes": [2, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','13'"}, "24": {"attributes_values": {"1": "M", "3": "Blue"}, "attributes": [2, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','14'"}, "23": {"attributes_values": {"1": "M", "3": "Yellow"}, "attributes": [2, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'2','16'"}, "27": {"attributes_values": {"1": "L", "3": "Yellow"}, "attributes": [3, 16], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','16'"}, "30": {"attributes_values": {"1": "L", "3": "Black"}, "attributes": [3, 11], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','11'"}, "29": {"attributes_values": {"1": "L", "3": "Orange"}, "attributes": [3, 13], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','13'"}, "28": {"attributes_values": {"1": "L", "3": "Blue"}, "attributes": [3, 14], "price": 0, "specific_price": {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"}, "ecotax": 0, "weight": 0, "quantity": 300, "reference": null, "unit_impact": "0.000000", "minimal_quantity": "1", "available_date": "", "id_image": -1, "list": "'3','14'"}};
    var comparator_max_item = 3;
    var comparedProductsIds = [];
    var confirm_report_message = 'Are you sure you want report this comment?';
    var contentOnly = false;
    var currencyBlank = 0;
    var currencyFormat = 1;
    var currencyRate = 1;
    var currencySign = '$';
    var currentDate = '2015-04-04 21:36:44';
    var customerGroupWithoutTax = true;
    var customizationFields = false;
    var customizationIdMessage = 'Customization #';
    var default_eco_tax = 0;
    var delete_txt = 'Delete';
    var displayDiscountPrice = '0';
    var displayList = true;
    var displayPrice = 1;
    var doesntExist = 'This combination does not exist for this product. Please select another combination.';
    var doesntExistNoMore = 'This product is no longer in stock';
    var doesntExistNoMoreBut = 'with those attributes but is available with others.';
    var ecotaxTax_rate = 0;
    var fieldRequired = 'Please fill in all the required fields before saving your customization.';
    var freeProductTranslation = 'Free!';
    var freeShippingTranslation = 'Free shipping!';
    var generated_date = 1428197804;
    var group_reduction = 0;
    var idDefaultImage = 102;
    var id_lang = 1;
    var id_product = 5;
    var img_dir = 'http://demo4leotheme.com/prestashop/leo_flowers/themes/leoflowers/img/';
    var img_prod_dir = 'http://demo4leotheme.com/prestashop/leo_flowers/img/p/';
    var img_ps_dir = 'http://demo4leotheme.com/prestashop/leo_flowers/img/';
    var instantsearch = false;
    var isGuest = 0;
    var isLogged = 0;
    var isMobile = false;
    var jqZoomEnabled = false;
    var loggin_required = 'You must be logged in to manage your wishlist.';
    var maxQuantityToAllowDisplayOfLastQuantityMessage = 3;
    var max_item = 'You cannot add more than 3 product(s) to the product comparison';
    var min_item = 'Please select at least one product';
    var minimalQuantity = 1;
    var moderation_active = true;
    var mywishlist_url = 'http://demo4leotheme.com/prestashop/leo_flowers/index.php?fc=module&module=blockwishlist&controller=mywishlist&id_lang=1';
    var noTaxForThisProduct = true;
    var oosHookJsCodeFunctions = [];
    var page_name = 'product';
    var placeholder_blocknewsletter = 'Enter your e-mail';
    var priceDisplayMethod = 1;
    var priceDisplayPrecision = 2;
    var productAvailableForOrder = true;
    var productBasePriceTaxExcl = 30.506321;
    var productBasePriceTaxExcluded = 30.506321;
    var productHasAttributes = true;
    var productPrice = 28.98;
    var productPriceTaxExcluded = 30.506321;
    var productPriceWithoutReduction = 30.506321;
    var productReference = 'demo_5';
    var productShowPrice = true;
    var productUnitPriceRatio = 0;
    var product_fileButtonHtml = 'Choose File';
    var product_fileDefaultHtml = 'No file selected';
    var product_specific_price = {"id_specific_price": "1", "id_specific_price_rule": "0", "id_cart": "0", "id_product": "5", "id_shop": "0", "id_shop_group": "0", "id_currency": "0", "id_country": "0", "id_group": "0", "id_customer": "0", "id_product_attribute": "0", "price": "-1.000000", "from_quantity": "1", "reduction": "0.050000", "reduction_tax": "1", "reduction_type": "percentage", "from": "0000-00-00 00:00:00", "to": "0000-00-00 00:00:00", "score": "32"};
    var productcomment_added = 'Your comment has been added!';
    var productcomment_added_moderation = 'Your comment has been added and will be available once approved by a moderator';
    var productcomment_ok = 'OK';
    var productcomment_title = 'New comment';
    var productcomments_controller_url = 'http://demo4leotheme.com/prestashop/leo_flowers/index.php?fc=module&module=productcomments&controller=default&id_lang=1';
    var productcomments_url_rewrite = false;
    var quantitiesDisplayAllowed = true;
    var quantityAvailable = 3600;
    var quickView = true;
    var reduction_percent = 5;
    var reduction_price = 0;
    var removingLinkText = 'remove this product from my cart';
    var roundMode = 2;
    var search_url = 'http://demo4leotheme.com/prestashop/leo_flowers/index.php?controller=search';
    var secure_key = '605fc1fd10dfbe95782621d3dc7f1609';
    var sharing_img = 'http://demo4leotheme.com/prestashop/leo_flowers/img/p/1/0/2/102.jpg';
    var sharing_name = 'Printed Summer Dress';
    var sharing_url = 'http://demo4leotheme.com/prestashop/leo_flowers/index.php?id_product=5&controller=product&id_lang=1';
    var specific_currency = false;
    var specific_price = -1;
    var static_token = 'b780f4fb17b185b4b307d81526c2320c';
    var stf_msg_error = 'Your e-mail could not be sent. Please check the e-mail address and try again.';
    var stf_msg_required = 'You did not fill required fields';
    var stf_msg_success = 'Your e-mail has been sent successfully';
    var stf_msg_title = 'Send to a friend';
    var stf_secure_key = '5e24bf3e3b3212772a347745e55c171b';
    var stock_management = 1;
    var taxRate = 0;
    var token = 'b780f4fb17b185b4b307d81526c2320c';
    var upToTxt = 'Up to';
    var uploading_in_progress = 'Uploading in progress, please be patient.';
    var usingSecureMode = false;
    var wishlistProductsIds = false;
</script>

<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.js"></script>
<script type="text/javascript" src="js/tools.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/10-bootstrap.min.js"></script>
<script type="text/javascript" src="js/15-jquery.total-storage.min.js"></script>
<script type="text/javascript" src="js/15-jquery.uniform-modified.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/products-comparison.js"></script>
<script type="text/javascript" src="js/ajax-cart.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.js"></script>
<script type="text/javascript" src="js/jquery.serialScroll.js"></script>
<script type="text/javascript" src="js/jquery.bxslider.js"></script>
<script type="text/javascript" src="js/treeManagement.js"></script>
<script type="text/javascript" src="js/blocknewsletter/blocknewsletter.js"></script>
<script type="text/javascript" src="js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="js/blocksearch.js"></script>
<script type="text/javascript" src="js/homeslider.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/jquery.cooki-plugin.js"></script>
<script type="text/javascript" src="js/colorpicker.js"></script>
<script type="text/javascript" src="js/paneltool.js"></script>
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/jquery.themepunch.enablelog.js"></script>
<script type="text/javascript" src="js/jquery.themepunch.revolution.js"></script>
<script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/ajax-wishlist.js"></script>
<script type="text/javascript" src="js/index.js"></script>
<script type="text/javascript" src="js/leocustomajax.js"></script>
<link rel="stylesheet" type="text/css" href="<?= CSS ?>responsive.css"/>
<link rel="stylesheet" type="text/css" href="<?= CSS ?>font-awesome.min.css"/>


<link rel="stylesheet" href="<?= CSS ?>test33.css" type="text/css" media="all"/>


<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>

<style>
    #thumbnail_86 {
        width: 18%;
        float: left;
        margin-right: 23px;
        border: 1px solid #CCC;
        margin-bottom: 20px;
    }
</style>


</head>
<body id="product"
      class="product product-7 product-printed-chiffon-dress category-11 category-summer-dresses hide-left-column lang_en fullwidth  double-menu">
<section id="page" data-column="col-xs-12 col-sm-6 col-md-3" data-type="grid">
<!-- Header -->
    <?php $this->load->view('inc/header'); ?>
    <?php $this->load->view('inc/nav'); ?>

<!-- Content -->
<section id="columns" class="columns-container">
    <div class="container">

        <div class="row">


            <!-- Center -->
            <section id="center_column" class="col-md-12">
                <div id="breadcrumb" class="clearfix">

                    <!-- Breadcrumb -->
                    <div class="breadcrumb clearfix">
                        <a class="home" href="" title="Return to Home"><i class="fa fa-home"></i></a>
                        <span class="navigation-pipe">&gt;</span>
                            <span class="navigation_page"><span itemscope itemtype=""><a itemprop="url" href=""
                                                                                         title="Women"><span
                                            itemprop="title">Home</span></a></span><span
                                    class="navigation-pipe">></span>Gallery</span>
                    </div>
                    <!-- /Breadcrumb -->
                </div>


                <div class="primary_block row" itemscope itemtype="http://schema.org/Product">
                    <div class="container">
                        <div class="top-hr"></div>
                    </div>
                    <!-- left infos-->
                    <div class="pb-left-column col-xs-12 col-sm-12 col-md-12">

                        <div id="views_block" class="clearfix ">
                            <div id="thumbs_list">
                                <ul id="thumbs_list_frame">
                                    <?php foreach($record as $obj ): ?>
                                        <li id="thumbnail_86">
                                            <a href="<?= UPLOAD_THUMBS. $obj->image?>" data-fancybox-group="other-views"
                                               class="fancybox" title="">
                                                <img class="img-responsive" id="thumb_86" src="<?= UPLOAD. $obj->image?>"
                                                     alt="" title="" itemprop="image"/>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <!-- end thumbs_list -->
                        </div>
                    </div>
                    <!-- end pb-left-column -->

                </div>
                <!-- end primary_block -->


            </section>
            <!-- Right -->


        </div>
    </div>
</section>
<!-- Footer -->
    <?php $this->load->view('inc/footer'); ?>
<!-- .footer-container -->
</section>
<!-- #page -->


</body>
</html>