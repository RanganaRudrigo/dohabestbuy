<!-- Page Content -->
<div id="page-wrapper">
    <div class="tab-content container-fluid">

    </div>
    <!-- /.container-fluid -->
</div>

<!-- /#page-wrapper -->
