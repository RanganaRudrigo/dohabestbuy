<?=doctype('html5')?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?=PROJECT_TITLE?></title>
    <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.png"/>
    <!-- Bootstrap Core CSS -->
    <?= link_tag('assets/css/bootstrap.min.css');?>
    <!-- MetisMenu CSS -->
    <?= link_tag('assets/css/plugins/metisMenu/metisMenu.min.css');?>
    <!-- Custom CSS -->
    <?= link_tag('assets/css/admin.css');?>
    <!-- DataTables CSS -->
    <?= link_tag('assets/css/plugins/dataTables.bootstrap.css');?>
    <!-- Custom Fonts -->
    <?= link_tag('assets/font-awesome/css/font-awesome.min.css');?>

    <?= link_tag('assets/css/plugins/uploader/blueimp-gallery.min.css');?>

    <!-- CSS to style the file input field as button and adjust the Bootstrap progress bars -->
    <?= link_tag('assets/css/plugins/uploader/jquery.fileupload.css');?>
    <?= link_tag('assets/css/plugins/uploader/jquery.fileupload-ui.css');?>
    <!-- CSS adjustments for browsers with JavaScript disabled -->
    <noscript>
        <?= link_tag('assets/css/plugins/uploader/jquery.fileupload-noscript.css');?>
    </noscript>
    <noscript>
        <?= link_tag('assets/css/plugins/uploader/jquery.fileupload-ui-noscript.css');?>
    </noscript>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script >
        var URL = {
            base : '<?=base_url()?>',
            current : '<?=current_url()?>'
        }
    </script>
</head>

<body>
