

<div id="wrapper">

<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
<div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="<?=base_url()?>admin"><img src="<?=base_url()?>assets/images/logo.png" class="img-responsive" ></a>
</div>
<!-- /.navbar-header -->

<ul class="nav navbar-top-links navbar-right">
<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
        <i class="fa fa-envelope fa-fw"></i>  <i class="fa fa-caret-down"></i>
    </a>
    <ul class="dropdown-menu dropdown-messages">
        <li>
            <a href="#">
                <div>
                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                </div>
                <div> asd asda sds</div>
            </a>
        </li>
    </ul>
    <!-- /.dropdown-messages -->
</li>
<!-- /.dropdown -->
<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
        <i class="fa fa-bell fa-fw"></i>  <i class="fa fa-caret-down"></i>
    </a>
    <ul class="dropdown-menu dropdown-alerts">
        <li>
            <a href="#">
                <div>
                    <i class="fa fa-comment fa-fw"></i> New Comment
                    <span class="pull-right text-muted small">4 minutes ago</span>
                </div>
            </a>
        </li>
    </ul>
    <!-- /.dropdown-alerts -->
</li>
<!-- /.dropdown -->
<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i>
<!--        <img src="--><?//=base_url();?><!--assets/images/user.jpg" class="img-circle  " width="30" >-->
        <i class="fa fa-caret-down"></i>
    </a>
    <ul class="dropdown-menu dropdown-user">
        <li><a href="#">
                <i class="fa fa-user fa-fw"></i>
                User Profile</a>
        </li>
        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
        </li>
        <li class="divider"></li>
        <li>
                <?=form_open()?>
                <button class="btn btn-link" name="logout" value="1" ><i class="fa fa-sign-out fa-fw"></i> Logout</button>
                <?=form_close()?>

        </li>
    </ul>
    <!-- /.dropdown-user -->
</li>
<!-- /.dropdown -->
</ul>
<!-- /.navbar-top-links -->

<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                <div class="input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                </div>
                <!-- /input-group -->
            </li>
            <li>
                <a class="active" href="<?=base_url()?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
            </li>
            <li>
                <a href="#"  ><i class="fa fa-list-alt fa-fw"></i> Menu <span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?=ADMIN?>menu"><i class='fa fa-list-alt fa-fw' ></i> View Menu</a>
                    </li>
                    <li>
                        <a href="<?=ADMIN?>menu/add"><i class='fa fa-pencil-square-o fa-fw' ></i>  Add New Menu</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#"  ><i class="fa fa-list-alt fa-fw"></i> Product <span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?=ADMIN?>product"><i class='fa fa-list-alt fa-fw' ></i> View Product</a>
                    </li>
                    <li>
                        <a href="<?=ADMIN?>product/add"><i class='fa fa-pencil-square-o fa-fw' ></i> Add New Product</a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="#"  ><i class="fa fa-list-alt fa-fw"></i> Slider <span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?=ADMIN?>slider"><i class='fa fa-list-alt fa-fw' ></i> View slider</a>
                    </li>
                    <li>
                        <a href="<?=ADMIN?>slider/add"><i class='fa fa-pencil-square-o fa-fw' ></i> Add New slider</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#"  ><i class="fa fa-list-alt fa-fw"></i> Banner <span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?=ADMIN?>banner"><i class='fa fa-list-alt fa-fw' ></i> View Banner</a>
                    </li>
                    <li>
                        <a href="<?=ADMIN?>banner/add"><i class='fa fa-pencil-square-o fa-fw' ></i> Add New Banner</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#"  ><i class="fa fa-photo fa-fw"></i> Gallery <span class="fa arrow"></span> </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?=ADMIN?>gallery"><i class='fa fa-list-alt fa-fw' ></i> View Gallery</a>
                    </li>
                    <li>
                        <a href="<?=ADMIN?>gallery/add"><i class='fa fa-pencil-square-o fa-fw' ></i> Add New Gallery</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?=ADMIN?>order"><i class='fa fa-pencil-square-o fa-fw' ></i>Manage Home Screen</a>
            </li>

            <li>
                <a href="<?=ADMIN?>upload"  ><i class="fa fa-photo fa-fw"></i> Upload Image </a>
            </li>


        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->
</nav>
