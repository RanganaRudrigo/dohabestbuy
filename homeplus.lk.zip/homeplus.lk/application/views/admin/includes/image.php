<div id="image" class="tab-pane fade in">
    <h4></h4>

    <div class="row sortable ui-sortable">

        <div class="col-lg-2 left ui-sortable-handle">
            <div class="img-thumbnail">
                <div class="row">
                    <div class="col-xs-12">
                        <img src="<?=IMAGE?>ic_add_box_48px-128.png"
                             class="img-rounded addMore_image" id="clicker" width="128" height="128" title="" alt="">
                    </div>
                </div>
            </div>
        </div>
        <?php foreach($result->sub_image as $image ): ?>
        <div class="col-md-2 left MB5 ui-state-default ">
            <div class="img-thumbnail">
                <div class="row">
                    <div class="col-sm-12">
                        <img width="128" height="128" rel="lightbox" title="imaget"
                             class="img-rounded img-responsive upload_image" alt="Image"     src="<?=UPLOAD_THUMBS.$image->image?>">
                        <input type="hidden" name="sub_image[image][]" value="<?=$image->image?>">
                    </div>
                    <div class="col-xs-offset-2"><a role="button" href="#" class="btn btn-primary btn-xs upload_image ">Browse</a>
                        <a role="button" href="#" class="btn btn-default btn-xs remove_image">Clear </a></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>