<?php

define('UPLOAD',base_url() . 'uploads/');
define('UPLOAD_THUMBS',base_url() . 'uploads/thumbs/');
define('ADMIN',base_url() . 'admin/');
define('IMAGE',base_url() . 'assets/images/');

$this->load->view('admin/includes/header.php');
$this->load->view('admin/includes/menu.php');
$this->load->view("admin/".$view);
$this->load->view('admin/includes/footer_details.php');
$this->load->view('admin/includes/js.php');
$this->load->view('admin/includes/footer.php');