<div id="video" class="tab-pane fade in">
    <h1></h1>
    <?= form_error('video[url]'); ?>
    <table class="table table-striped table-bordered table-hover" id="myTable">
        <thead>
        <tr>
            <th>#</th>
            <th>viedo url <span class="text-danger">(youtube only)</span></th>
            <th>Check</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody class="video_panel ui-sortable">
        <tr id="default_row" class="ui-sortable-handle">
            <td colspan="3"></td>
            <td>
                <button type="button" class=" addMore_video btn btn-primary" id="add_new_row">
                    Add more
                </button>
            </td>
        </tr>
        <?php foreach($result->video as $k => $video ): ?>
            <tr>
                <td class="row_id"><?=$k+1?></td>
                <td><input type="text" class="form-control" placeholder="Video URL" value="<?=$video->url?>" name="video[url][]"></td>
                <td>
                    <button type="button" class="check_video btn btn-success">Check</button>
                </td>
                <td>
                    <button type="button" class=" remove_video btn btn-danger">Remove</button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

</div>