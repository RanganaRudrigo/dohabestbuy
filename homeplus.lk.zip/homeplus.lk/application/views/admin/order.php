<!-- Page Content -->
<div id="page-wrapper">
    <!-- master -->
    <div class="row" id="master">
        <div class="col-lg-12">
            <h1 class="page-header">Product reorder for home page </h1>
        </div>
        <!-- /.col-lg-12 -->

    </div>
    <div class="row" >
        <?php
        if(isset($valid)) $error = $valid;

        if(isset($error)){
            ?>
            <div class="alert <?=isset($valid)?  'alert-success' : 'alert-danger'?> alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?=$error?>
            </div>
        <?php
        }

        ?>
    </div>
    <!-- /.master -->
    <div class="row" >
        <?=form_open()?>
        <div class="tab-content container-fluid">
            <div class="panel-body">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#feature">Feature</a>    </li>
                    <li ><a data-toggle="tab" href="#best">Best Seller</a>    </li>

                    <li class="pull-right">
                        <button class="btn btn-default"  type="submit">Save</button>
                        <button class="btn btn-danger" type="reset">Reset</button>
                    </li>
                </ul>
                <input type="hidden" value="1" name="submit" >
                <!-- Tab panes -->
                <div class="tab-content">
                    <h1></h1>

                    <div id="feature" class="tab-pane fade in active">
                        <div class="form-group  ">
                            <div class="col-lg-5 input-group ">
                                <label> Product Name </label>
                                <input type="text" name="" placeholder="Product Name" i data-for="feature_product" class="form-control input-sm product_link " autocomplete="off" autocorrect="off" autocapitalize="off">
                                    <span class="input-group-addon hidden loader">
                                        <img src="<?= IMAGE ?>loading.gif" width="25" class="loader_ajaxs"/>
                                     </span>
                                <ul id="feature_product" class="form-group hidden " >
                                </ul>
                                <div class="feature_product  link m5 form-control " >
                                </div>
                            </div>
                        </div>
                    </div>




                    <div id="best" class="tab-pane fade in ">
                        <div class="form-group  ">
                            <div class="col-lg-5 input-group ">
                                <label> Product Name  </label>
                                <input type="text" name="" placeholder="Product Name"  data-for="best_seller" class="form-control input-sm  product_link " autocomplete="off" autocorrect="off" autocapitalize="off">
            <span class="input-group-addon hidden loader">
                <img src="<?= IMAGE ?>loading.gif" width="25" class="loader_ajaxs"/>
             </span>
                                <ul id="best_seller" class="form-group  hidden " >
                                </ul>
                                <div class="best_seller link  m5 form-control " >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?=form_close()?>
        <!-- /.container-fluid -->
    </div>
</div>

<!-- /#page-wrapper -->
