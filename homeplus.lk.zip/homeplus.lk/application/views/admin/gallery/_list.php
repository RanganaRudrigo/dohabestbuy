
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">View Gallery</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Gallery List
                        <div class="btn-group pull-right">
                            <a href="<?=base_url()?>admin/gallery/add" class="btn btn-primary btn-outline btn-xs " type="button" >Add New gallery</a>
                        </div>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body  ">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTable">
                                <thead>
                                <tr>
                                    <th  >#</th>
                                    <th style="width: 10%" >Code no</th>
                                    <th style="width: 10%" >Image</th>
                                    <th style="width: 10%" >Status</th>
                                    <th class="text-right" ><span class="m5" >Edit </span></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                if(is_array($record)):
                                    foreach($record as $k => $row):
                                        ?>
                                        <tr class="">
                                            <td><?=$k+1?></td>
                                            <td><?=$row->code?></td>
                                            <td class="text-center"><img  src="<?=UPLOAD_THUMBS.$row->image?>" width="50"  ></td>
                                            <td class="center"><?=$row->status? "Active" : "Deactive" ?></td>
                                            <td class="text-right">
                                                <a class="btn btn-social btn-info btn-sm m5" href="<?=base_url()."admin/gallery/update/".$row->id?>" >
                                                    <i class="fa fa-gears fa-fw" ></i> update
                                                </a>
                                                <?= form_open() ?>
                                                <button class="btn btn-social btn-danger btn-sm m5 delete_btn " type="submit" >
                                                    <i class="fa fa-times-circle fa-fw" ></i> delete
                                                </button>
                                                <input type="hidden" name='id' value="<?=$row->id?>" />
                                                <input type="hidden" name='form[status]' value="2" />
                                                <input type="hidden" name='form[user_id]' value="<?=$this->session->userdata('id')?>" />
                                                <?= form_close()?>
                                            </td>

                                        </tr>
                                    <?php
                                    endforeach;
                                endif;
                                ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->

                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->
</div>

<!-- /#page-wrapper -->
