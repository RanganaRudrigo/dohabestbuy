
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Please Sign In</h3>
                </div>
                <div class="panel-body">
                    <?=$error?>
                    <?=form_open()?>
                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="Username" name="name" type="text" autofocus>
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Password" name="password" type="password" value="">
                        </div>
                        <!-- Change this to a button or input when using this as a form -->
                        <button class="btn btn-lg btn-success btn-block">Login</button>
                    </fieldset>
                    <p class="text-center"><small>Copyrights © <?=date('Y')?> <?=PROJECT_TITLE?> </small></p>
                    <?=form_close()?>
                </div>
                <p class="right" id="footer"> Powered by <a href="http://www.itmartx.com/" target="_blank">ITMARTX</a> </p>
            </div>
        </div>
    </div>
</div>
