<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row" >
            <h1></h1>
            <form id="upload_doc" class="" action="upload_doc" method="POST" enctype="multipart/form-data">
                <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
                <div class="row fileupload-buttonbar text-center ">
                    <div class="col-lg-10">
                        <!-- The fileinput-button span is used to style the file input field as button -->
            <span class="btn btn-success fileinput-button">
                <i class="glyphicon glyphicon-plus"></i>
                <span>Add files...</span>
                <input type="file" name="userfile[]" multiple  >
            </span>

                        <button class="btn btn-info " > upload </button>
                    </div>
                </div>

                <h1></h1>
                <div class="progress progress-striped active hidden">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 00%">
                    </div>
                </div>
                <h1></h1>
                <div class="doc" >
                </div>
            </form>
        </div>
    </div>
</div>