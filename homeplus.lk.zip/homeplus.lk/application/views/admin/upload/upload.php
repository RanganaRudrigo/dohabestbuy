<style>
    #fileupload{
        height: auto !important;
        overflow: hidden !important;
    }
</style>
<div id="page-wrapper">
    <div class="container-fluid">

        <div class="row" >
            <h1></h1>


        <base href="<?php echo base_url(); ?>">

        <div class="row" >
            <div class="col-lg-12 text-center" >
                <!-- The file upload form used as target for the file upload widget -->
        <form id="fileupload" action="upload/do_upload" method="POST" enctype="multipart/form-data">
            <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
            <div class="row fileupload-buttonbar">
                <div class="col-lg-10">
                    <!-- The fileinput-button span is used to style the file input field as button -->
            <span class="btn btn-success fileinput-button">
                <i class="glyphicon glyphicon-plus"></i>
                <span>Add files...</span>
                <input type="file" name="userfile" multiple>
            </span>
                    <button type="submit" class="btn btn-primary start">
                        <i class="glyphicon glyphicon-upload"></i>
                        <span>Start upload</span>
                    </button>
                    <button type="reset" class="btn btn-warning cancel">
                        <i class="glyphicon glyphicon-ban-circle"></i>
                        <span>Cancel upload</span>
                    </button>
<!--                    <button type="button" class="btn btn-danger delete">-->
<!--                        <i class="glyphicon glyphicon-trash"></i>-->
<!--                        <span>Delete</span>-->
<!--                    </button>-->
                    <!-- The global file processing state -->
                    <span class="fileupload-process"></span>
                </div>
               
            </div>
            <h1></h1>
           <div class="files" >

            </div>
        </form>
            </div>
        </div>

        <!-- The blueimp Gallery widget -->
        <div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls" data-filter=":even">
            <div class="slides"></div>
            <h3 class="title"></h3>
            <a class="prev">‹</a>
            <a class="next">›</a>
            <a class="close">×</a>
            <a class="play-pause"></a>
            <ol class="indicator"></ol>
        </div>

        </div>
    </div>
</div>