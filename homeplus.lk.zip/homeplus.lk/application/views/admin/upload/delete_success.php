<?php
echo 'file:' .$delete_data .'-deleted' ;
?>