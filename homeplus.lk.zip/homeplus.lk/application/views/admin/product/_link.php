<div id="link" class="tab-pane fade in ">
    <div class="clearfix"></div>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Menu Name  </label>
            <input type="text" name="" placeholder="Menu title" id="cat_link" class="form-control input-sm " autocomplete="off" autocorrect="off" autocapitalize="off">
            <span class="input-group-addon hidden loader">
                <img src="<?= IMAGE ?>loading.gif" width="25" class="loader_ajaxs"/>
             </span>
            <ul class="form-group  ajax_cat_result hidden " >
            </ul>
            <div class="link  m5 form-control " >
                <?php foreach( $result->menu as $menu ): ?>
                    <div class="result_div" id="menu_<?=$menu->m_id?>"> <?=$menu->name?>
                        <input type="hidden" name="menu[]" value="<?=$menu->m_id?>">
                        <input type="hidden" name="menu_name[]" value="<?=$menu->name?>">
                        <i  class=" pull-right fa-2x text-danger fa fa-times"></i></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

</div>