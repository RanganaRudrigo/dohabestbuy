<div id="page-wrapper" >
    <div class=" container-fluid">
        <!-- master -->
        <div class="row" id="master">
            <div class="col-lg-12">
                <h1 class="page-header">Add New Product
                    <div class="btn-group pull-right">
                        <a href="<?=ADMIN?>product" class="btn btn-primary btn-outline btn-xs " type="button">Manage</a>
                    </div>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.master -->

        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-6 col-md-6 col-sm-12 pull-right">
                    <div class="input-group custom-search-form">
                        <input type="search" class="form-control input-sm" for="airline" placeholder="Search..." autocomplete="off" autocorrect="off" autocapitalize="off">
                                <span class="input-group-btn">
                                <button class="btn btn-default btn-sm" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <?=@$error?>

            <div class="col-lg-12">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="col-lg-5">
                                <table class="table table-bordered">
                                    <tbody><tr>
                                        <th>System code </th>
                                        <td>&nbsp;<?=$result->code?> </td>
                                    </tr>
                                    <tr>
                                        <th>Date </th>
                                        <td> &nbsp;<?=date('Y-M-d',strtotime($result->date))?></td>
                                    </tr>
                                    </tbody></table>
                            </div>
                            <div class="clearfix"></div>

                            <div class="panel panel-default">
                                <?=form_open()?>
                                <input type="hidden" name="id" value="<?=$result->id?>" >
                                <input type="hidden" name="form[code]"  value="<?=$result->code?>" >
                                <input type="hidden" name="form[date]" value="<?=$result->date?>" >
                                <input type="hidden" name='form[user_id]' value="<?=$this->session->userdata('id')?>" />
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a data-toggle="tab" href="#general">General</a>    </li>
                                        <li ><a data-toggle="tab" href="#link">Menu Link</a>    </li>
                                        <li ><a data-toggle="tab" href="#data">Data</a>    </li>
                                        <li ><a data-toggle="tab" href="#image">Image</a>    </li>
                                       <!-- <li ><a data-toggle="tab" href="#video">Video</a>    </li> -->
                                        <li class="pull-right">
                                            <button class="btn btn-default" type="submit">Save</button>
                                            <button class="btn btn-danger" type="reset">Reset</button>
                                        </li>
                                    </ul>
                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <h1></h1>
                                        <div id="general" class="tab-pane fade in active">
                                            <div class="clearfix"></div>
                                            <div class="form-group  ">
                                                <div class="col-lg-5 input-group ">
                                                    <label>Product Name <i class="text-center text-danger fa fa-asterisk "></i> </label>
                                                    <input type="text" name="form[title]" value="<?=$result->title?>" placeholder="Product Title" class="form-control input-sm" autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
                                                    <?= form_error('form[title]'); ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Default Image</label>

                                                <div class="clearfix"></div>
                                                <div class="img-thumbnail">
                                                    <div class="row">
                                                        <div class="col-xs-12">
                                                            <img src="<?=strlen($result->image) == 0 ? IMAGE."picture-01-128.png" : UPLOAD_THUMBS.$result->image ?>" alt="" class="img-rounded upload_image img-thumbnail " width="128" height="128" >
                                                            <input type="hidden" name="form[image]" value="<?=$result->image?>">
                                                        </div>
                                                        <div class="col-xs-offset-2">
                                                            <a class="btn btn-primary btn-xs upload_image " href="#" role="button">Browse</a>
                                                            <a class="btn btn-default btn-xs clear_image " href="#" role="button">Clear </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?= form_error('form[image]'); ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Short Description</label>
                                                <textarea name="form[short]" cols="40" rows="3" placeholder="Short Description" class="form-control"><?=$result->short?></textarea>
                                                <?= form_error('form[short]'); ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea name="form[long]" cols="40" rows="3" placeholder="Short Description" class="form-control des"><?=$result->long?></textarea>
                                                <?= form_error('form[long]'); ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Status</label>
                                                <div class="col-lg-3 input-group" >
                                                    <select name="form[status]" class="form-control" >
                                                        <?php foreach($result->status_array as $status): ?>
                                                            <option value="<?=$status->id?>" <?=$result->status == $status->id ? "selected":""?>  > <?=$status->name?> </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <?php $this->load->view('admin/includes/image'); ?>
                                        <?php $this->load->view('admin/product/_data'); ?>
                                        <?php $this->load->view('admin/product/_link'); ?>
                                        <?php //$this->load->view('admin/includes/video'); ?>
                                    </div>
                                </div>
                                <?=form_close()?>            <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
                <!--                </div>-->
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>

    </div>
    <!-- /.container-fluid -->
</div>