<div id="data" class="tab-pane fade in">
    <h4></h4>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Price </label>
            <input type="text" name="form[price]" value="<?=$result->price?>" placeholder="" class="form-control input-sm price " autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
            <?= form_error('form[price]'); ?>
        </div>
    </div>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Discount Price </label>
            <input type="text" name="form[discount_price]" value="<?=$result->discount_price?>" placeholder="" class="form-control input-sm price" autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
            <?= form_error('form[discount_price]'); ?>
        </div>
    </div>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Quantity</label>
            <input type="text" name="form[qty]" value="<?=$result->qty?>" placeholder="" class="form-control input-sm" autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
            <?= form_error('form[qty]'); ?>
        </div>
    </div>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Weights</label>
            <div class="input-group">
                <input type="text" name="form[weight]" value="<?=$result->weight?>" placeholder="" class="form-control input-sm" autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
                  <span class="input-group-btn">
                    <select class="btn" name="form[weight_type]" >
                        <?php foreach($result->weight_array as $status): ?>
                            <option value="<?=$status->id?>" <?=$result->weight_type == $status->id ? "selected":""?>  > <?=$status->name?> </option>
                        <?php endforeach; ?>

                    </select>
                  </span>
            </div>
            <?= form_error('form[weight]'); ?>
        </div>
    </div>
    <div class="form-group  ">
        <div class="col-lg-5 input-group ">
            <label>Metal</label>
            <input type="text" name="form[metal]" value="<?=$result->metal?>" placeholder="" class="form-control input-sm" autofocus="" autocomplete="off" autocorrect="off" autocapitalize="off">
            <?= form_error('form[metal]'); ?>
        </div>
    </div>
</div>